## v4.4 website boundary
Local saved customer cards are separate from website payment methods. Adding, deleting, distributing, and exporting locally saved cards never calls a website payment write route. A local card may be associated with an existing website customer ID for lookup, but no card secrets are transmitted to the website.

# SLABSNGRABSACO ACO Studio — Website & Customers (integration notes)

This is the **private-owner** desktop edition. Only this edition includes the website customer connector and Email Gen. Its shareable counterpart does not contain any website or Email Gen integration.

## Getting started

1. Follow `BUILD_AND_INSTALL.md` in this package. The working launcher scripts are at the ZIP root: `start-aco-studio-windows.bat` and `start-aco-studio-mac.command`.
2. Select **Website & Customers** (the opening Home tab).
3. Choose **Secure Admin sign-in**. A separate Electron browser window opens `https://slabsngrabsaco.com/admin.html` with the actual website's Admin login. Complete the normal password, MFA/passkey, and any other site checks there.
4. Return to ACO Studio and click **Sync now**. The program reads paid and registered customers, membership allocations, linked inventory and customer addresses from the authenticated website. It does not store Admin passwords, payment data, or a second synced database.
5. Click a customer to view saved address sources, linked-account slots, and the currently available account pool for each retailer.
6. Assign one **exact available** retailer account to that customer. Confirm the operation. The website decides whether that record may be assigned. Refreshing inventory reads the website again, so an assigned record is no longer considered available.
7. On an existing linked account, choose a saved address and **Jig address** to submit the selected website-supported format options through the website's own jig endpoint. Changes are tied to the specific linked record on the website.
8. **Return to pool** asks the website to check both the current customer ID and the existing assignment ID before returning the record. If a record has changed, the website rejects the stale operation.
9. Click **Create profiles** and select the quantity, saved shipping and billing addresses, card references, and grouped postal formats. Each choice includes a fictional before/after example. Click **Jig · Create profiles** to prepare local drafts. This is a LOCAL preview; generated name edits are **not** silently written to customer data. Only the website-approved per-profile Jig action saves an address variation to a linked assignment.
10. Export Shikari Target CSV or Valor Walmart/Pokémon Center JSON for the selected draft profiles, including blank account-email slots that still need an assigned login. The application labels each profile `Customer Name 1`, `Customer Name 2`, etc. Account emails come from the linked retailer pool.

## Live updates

When authorized, ACO Studio attaches to the website's existing `GET /api/admin/live/events` Server-Sent Events feed through the signed-in Admin browser. On `data-change` it refreshes the roster and the open customer. If the stream is disconnected, a 60-second fallback check is used while the Home tab is visible. The editor preserves an open Create Profiles form during live refreshes so selected inputs are not reset and the scroll position is not forced. Changes appear in a 10-second dismissible popup and the encrypted owner notification history.

## Privacy and sensitive payment information

The website remains the source of truth. Data are requested only through the owner's authenticated session; not bundled into any ZIP, cloud cache, or sharing feature. Customer addresses, membership counts, and linked retailer login identifiers may appear in the private window after Admin sign-in.

**Raw customer payment account numbers, verification codes, website password secrets, payment security codes, and encrypted vault packages are not exported or copied into the Electron app.** Shikari and Valor files retain the exact corresponding payment field names, empty unless the user explicitly uses synthetic fixtures in an isolated local test dataset. Local-file import/export preserves user-supplied *untouched* fields in their original formats.

The website's existing backend may contain routes that retain full card details; they require an independent PCI/security audit. Never export or store actual CVVs. The desktop app deliberately avoids the website's generic linked-profile update endpoint because an older implementation overwrote customer card details if omitted from the request.

## Current limitations

- **Not yet independently tested against your authenticated live production account.** This package passed its local logic and package checks only; test with one authorized sample account before using it for customers.
- Website-side jig history, one-profile-per-account and inventory status rules are authoritative; an address preview never overrides website restrictions.
- The website does not currently expose a safely verified method to automatically save all of the locally randomized shipping and billing recipient names without risking existing saved payment details. These changes remain preview/export drafts; confirm them before using them.
- The desktop Home loads website customers directly. Clicking a customer **within ACO Studio** opens that customer's profile. A click on the external website's Admin page does not yet deep-link automatically into this unpackaged Electron project; a signed desktop protocol handler and website-side button remain future work.
- Creating, editing, deleting, or bulk importing available retailer logins is still performed through the existing website Admin inventory manager. ACO Studio reads and assigns from that same pool.
- The website's existing Admin session is required. Don't share this owner package or your Windows/macOS account with untrusted users.
- Billing details currently fall back to the customer-submitted membership shipping address when no separate billing-address record is present in the existing API. Review before export.
- The test-name preview is not an identity verification service or a guarantee of retailer deliverability.

## Troubleshooting

If **Sync now** says authentication required, finish signing in to the separate Admin window. Keep it open while using the app. Do not paste your website Admin password, Cloudflare API token, email passwords or customer card security codes into ChatGPT.

**Restoring Email Gen:** This new extracted version may have a different local file origin. Before replacing v3.4, make an encrypted Email Bank backup from the old private edition. Restore it after Cloudflare owner authorization in the new edition. Your live website records are not part of that backup.
