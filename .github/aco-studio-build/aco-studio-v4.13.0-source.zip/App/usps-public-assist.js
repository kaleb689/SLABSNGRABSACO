'use strict';
// Public USPS webpage workflow. No hidden requests, page scraping, or automatic
// harvesting. The owner opens the official page and enters its displayed result.
(function attach(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root && root.document) root.JigUSPSPublicAssistant = api;
})(typeof globalThis === 'object' ? globalThis : this, () => {
  const OFFICIAL_URL = 'https://tools.usps.com/zip-code-lookup.htm?byaddress';
  const FIELDS = [
    ['address1', 'Street address'], ['address2', 'Apt / Suite / Unit'],
    ['city', 'City'], ['state', 'State'], ['zip', '5-digit ZIP']
  ];
  const clean = value => String(value ?? '').trim();
  function normalizeAddress(input) {
    if (!input || typeof input !== 'object') throw Error('A saved address is required.');
    const address = Object.fromEntries(FIELDS.map(([key]) => [key, clean(input[key])]));
    if (!address.address1 || address.address1.length > 120 ||
        !/^[A-Z]{2}$/i.test(address.state) || !/^\d{5}(?:-\d{4})?$/.test(address.zip))
      throw Error('Map a street, two-letter state, and 5-digit ZIP before using USPS.');
    if (address.address2.length > 120 || address.city.length > 120)
      throw Error('This address contains a field too long for USPS lookup.');
    address.state = address.state.toUpperCase();
    address.zip = address.zip.slice(0, 5);
    return address;
  }
  function readVerifiedSuffix(value, zip) {
    const text = clean(value);
    const five = normalizeAddress({address1:'Example St',state:'FL',zip}).zip;
    const four = /^\d{4}$/.test(text) ? text : null;
    if (four) return four;
    const full = /^(\d{5})-?(\d{4})$/.exec(text);
    if (!full) throw Error('Enter the four-digit USPS suffix or the complete nine-digit ZIP.');
    if (full[1] !== five) throw Error('The USPS result has a different five-digit ZIP. Review the address before saving.');
    return full[2];
  }
  function resultRow(address, text) {
    const input = normalizeAddress(address);
    return {...input, zip4:readVerifiedSuffix(text, input.zip)};
  }
  function start({addresses,desktopAPI} = {}) {
    if (!Array.isArray(addresses) || addresses.length < 1 || addresses.length > 50)
      return Promise.reject(Error('Select between one and 50 saved addresses.'));
    if (typeof document === 'undefined')
      return Promise.reject(Error('USPS lookup assistant is available only in Jig Studio.'));
    const entries = addresses.map(normalizeAddress);
    if (document.querySelector('.uspsAssistOverlay'))
      return Promise.reject(Error('The USPS lookup assistant is already open.'));
    return new Promise(resolve => {
      let index = 0;
      let saves = [];
      let prevFocus = document.activeElement;
      const backdrop = document.createElement('div');
      backdrop.className = 'uspsAssistOverlay';
      backdrop.setAttribute('role','presentation');
      const panel = document.createElement('section');
      panel.className = 'uspsAssistPanel';
      panel.setAttribute('role','dialog');
      panel.setAttribute('aria-modal','true');
      panel.setAttribute('aria-labelledby','uspsAssistTitle');
      panel.innerHTML = `
        <header class="uspsAssistHead">
          <div><span class="uspsAssistEyebrow">OFFICIAL USPS / ZIP+4 BY ADDRESS</span>
            <h2 id="uspsAssistTitle">ZIP+4 lookup assistant</h2></div>
          <button type="button" class="btn slim plain" data-usps="close" aria-label="Close USPS lookup assistant">×</button>
        </header>
        <p class="uspsAssistIntro">Use the address already saved in Jig Studio. Click <strong>Open USPS</strong>, use the copy buttons to fill the USPS form, and enter the displayed ZIP+4 below. <strong>This is a manual lookup</strong>; the USPS website is not scraped.</p>
        <div class="uspsAssistProgress" role="status"></div>
        <div class="uspsAssistFields"></div>
        <div class="uspsAssistActions">
          <button type="button" class="btn primary" data-usps="open">↗ Open USPS By Address</button>
          <button type="button" class="btn slim secondary" data-usps="copy-full">Copy full address</button>
        </div>
        <label class="uspsAssistInput">ZIP+4 from USPS result
          <input type="text" inputmode="numeric" maxlength="10" autocomplete="off" spellcheck="false" placeholder="6789 or 12345-6789" aria-describedby="uspsAssistHint"></label>
        <p id="uspsAssistHint" class="tiny">The first five digits must match this customer's saved address. Nothing will be guessed.</p>
        <p class="uspsAssistMessage" aria-live="polite"></p>
        <footer class="uspsAssistFooter">
          <button type="button" class="btn primary" data-usps="save">Save verified ZIP+4 &amp; next</button>
          <button type="button" class="btn slim plain" data-usps="skip">Skip address</button>
          <button type="button" class="btn slim plain" data-usps="close">Finish</button>
        </footer>`;
      backdrop.append(panel);
      const get = selector => panel.querySelector(selector);
      const fieldPane = get('.uspsAssistFields');
      const input = get('.uspsAssistInput input');
      const progress = get('.uspsAssistProgress');
      const message = get('.uspsAssistMessage');
      const save = get('[data-usps="save"]');
      const skip = get('[data-usps="skip"]');
      const finish = () => {
        backdrop.remove();
        try { prevFocus?.focus(); } catch {}
        resolve({rows:saves, total:entries.length, skipped:entries.length - saves.length, source:'usps-public-manual'});
      };
      async function copy(field) {
        const address = entries[index];
        const value = field === 'full' ? [address.address1,address.address2,address.city,address.state,address.zip].filter(Boolean).join(', ') : address[field];
        if (!value) { message.textContent = 'There is no saved value in that field.'; return; }
        try {
          if (desktopAPI?.copyPublicZip4Field) await desktopAPI.copyPublicZip4Field(field, value);
          else if (navigator.clipboard?.writeText) await navigator.clipboard.writeText(value);
          else throw Error('Clipboard access unavailable.');
          message.textContent = 'Copied ' + (field === 'full' ? 'full address' : FIELDS.find(([key]) => key === field)?.[1]) + '. Paste it into the USPS page.';
        } catch (e) { message.textContent = 'Copy failed: ' + e.message; }
      }
      function render() {
        const a=entries[index];
        progress.textContent='Address ' + (index + 1) + ' of ' + entries.length + ' · ' + saves.length + ' ZIP+4 value(s) confirmed';
        fieldPane.replaceChildren();
        FIELDS.forEach(([key,label]) => {
          const row=document.createElement('div');row.className='uspsAssistField';
          const details=document.createElement('div');details.className='uspsAssistFieldValue';
          const title=document.createElement('small');title.textContent=label;
          const value=document.createElement('strong');value.textContent=a[key] || 'Not provided';
          details.append(title,value);
          const button=document.createElement('button');button.className='btn slim secondary';button.type='button';button.textContent='Copy';
          button.disabled=!a[key];button.addEventListener('click',()=>copy(key));
          row.append(details,button);fieldPane.append(row);
        });
        input.value='';message.textContent='';
        save.textContent=index===entries.length-1?'Save ZIP+4 & finish':'Save verified ZIP+4 & next';
        skip.textContent=index===entries.length-1?'Skip & finish':'Skip address';
      }
      function forward() {
        index++;
        if (index>=entries.length) return finish();
        render();input.focus();
      }
      get('[data-usps="open"]').addEventListener('click',async()=>{
        message.textContent='Opening the official USPS lookup in your browser...';
        try {
          if (desktopAPI?.publicZip4Lookup) await desktopAPI.publicZip4Lookup(entries[index]);
          else if (typeof window.open === 'function') window.open(OFFICIAL_URL,'_blank','noopener,noreferrer');
          else throw Error('Cannot open external browser.');
          message.textContent='USPS opened. The full address was copied; use the individual Copy buttons if needed.';
        } catch(e) { message.textContent='Cannot open USPS: '+e.message; }
      });
      get('[data-usps="copy-full"]').addEventListener('click',()=>copy('full'));
      save.addEventListener('click',()=>{
        try { saves.push(resultRow(entries[index],input.value));forward(); }
        catch(e) { message.textContent=e.message;input.focus(); }
      });
      skip.addEventListener('click',forward);
      for(const button of panel.querySelectorAll('[data-usps="close"]'))button.addEventListener('click',finish);
      backdrop.addEventListener('keydown',e=>{
        if(e.key==='Escape'){e.preventDefault();finish();}
        if(e.key==='Enter' && e.target===input){e.preventDefault();save.click();}
      });
      document.body.append(backdrop);
      render();get('[data-usps="open"]').focus();
    });
  }
  return Object.freeze({OFFICIAL_URL,normalizeAddress,readVerifiedSuffix,resultRow,start});
});
