'use strict';
// Hash-verified source-file updates. Create a complete update ZIP from the installed app
// without sending local customer data, credential stores, or userData to any server.
const fs=require('node:fs/promises');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const zlib=require('node:zlib');
const {randomUUID}=crypto;
const MAX_SOURCE_SIZE=25*1024*1024;
const MAX_ZIP_SIZE=25*1024*1024;
const CRC_TABLE=Array.from({length:256},(_,i)=>{let x=i;for(let j=0;j<8;j++)x=x&1?(x>>>1)^0xEDB88320:x>>>1;return x>>>0;});
const crc32=buf=>{let x=0xffffffff;for(const b of buf)x=CRC_TABLE[(x^b)&255]^(x>>>8);return (x^0xffffffff)>>>0;};
const permittedFile=name=>/^[A-Za-z0-9][A-Za-z0-9_.\/-]{0,149}$/.test(name)&&!name.includes('..')&&!name.includes('\\')&&!name.startsWith('/');
async function packageZip(root,out){
 const records=[];
 async function visit(dir,prefix){
  for(const entry of await fs.readdir(dir,{withFileTypes:true})){
   if(entry.isSymbolicLink())throw Error('Update source contains an unexpected symbolic link.');
   const next=path.join(dir,entry.name),name=prefix+'/'+entry.name;
   if(entry.isDirectory())await visit(next,name);
   else if(entry.isFile()){
    if(!permittedFile(name))throw Error('Unsafe file name in source archive.');
    records.push({name,data:await fs.readFile(next)});
   }else throw Error('Update contains an unsupported file type.');
  }
 }
 await visit(root,'App');
 if(records.length>500||records.reduce((n,r)=>n+r.data.length,0)>MAX_SOURCE_SIZE)throw Error('Installed app source is too large to update safely.');
 const local=[],central=[];let offset=0;
 for(const {name,data} of records){
  const filename=Buffer.from(name,'utf8'),compressed=zlib.deflateRawSync(data,{level:9}),crc=crc32(data);
  const header=Buffer.alloc(30);
  header.writeUInt32LE(0x04034b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(0x800,6);header.writeUInt16LE(8,8);
  header.writeUInt16LE(0,10);header.writeUInt16LE(0x21,12);header.writeUInt32LE(crc,14);
  header.writeUInt32LE(compressed.length,18);header.writeUInt32LE(data.length,22);header.writeUInt16LE(filename.length,26);header.writeUInt16LE(0,28);
  local.push(header,filename,compressed);
  const d=Buffer.alloc(46);
  d.writeUInt32LE(0x02014b50,0);d.writeUInt16LE(20,4);d.writeUInt16LE(20,6);d.writeUInt16LE(0x800,8);d.writeUInt16LE(8,10);
  d.writeUInt16LE(0,12);d.writeUInt16LE(0x21,14);d.writeUInt32LE(crc,16);
  d.writeUInt32LE(compressed.length,20);d.writeUInt32LE(data.length,24);d.writeUInt16LE(filename.length,28);
  d.writeUInt32LE(offset,42);central.push(d,filename);
  offset+=header.length+filename.length+compressed.length;
 }
 const cdSize=central.reduce((n,b)=>n+b.length,0);
 const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(records.length,8);end.writeUInt16LE(records.length,10);
 end.writeUInt32LE(cdSize,12);end.writeUInt32LE(offset,16);
 const archive=Buffer.concat([...local,...central,end]);
 if(archive.length>MAX_ZIP_SIZE)throw Error('Update ZIP would be too large.');
 await fs.writeFile(out,archive,{mode:0o600});
 return {bytes:archive.length,files:records.length};
}
async function prepare({baseDirectory,manifest,fetchFile,version}){
 if(!Array.isArray(manifest?.files)||typeof fetchFile!=='function')throw Error('Invalid update manifest.');
 const pkg=JSON.parse(await fs.readFile(path.join(baseDirectory,'package.json'),'utf8'));
 const existing=Array.isArray(pkg.build?.files)?pkg.build.files:null;
 if(!existing||new Set(existing).size!==existing.length||!existing.every(permittedFile))throw Error('Installed app has an invalid source file list.');
 const entries=new Map();
 for(const part of manifest.files){
  if(!permittedFile(part?.path)||entries.has(part.path)||typeof part.url!=='string'||!/^[a-f0-9]{64}$/i.test(part.sha256||''))
   throw Error('Update manifest contains invalid or duplicate source files.');
  entries.set(part.path,part);
 }
 if(!entries.has('package.json'))throw Error('Update must include the versioned package.json.');
 const verified=new Map();
 const fetchVerified=async part=>{
  if(verified.has(part.path))return verified.get(part.path);
  const bytes=await fetchFile(part.url);
  if(!Buffer.isBuffer(bytes)||bytes.length>3*1024*1024)throw Error('Update file exceeds allowed size.');
  if(crypto.createHash('sha256').update(bytes).digest('hex')!==part.sha256.toLowerCase())
   throw Error('Downloaded update file failed checksum verification.');
  verified.set(part.path,bytes);return bytes;
 };
 let next;
 try {next=JSON.parse((await fetchVerified(entries.get('package.json'))).toString('utf8'));}
 catch(e){if(/checksum|size/.test(e.message))throw e;throw Error('Update package.json is invalid.');}
 if(next.name!=='slabsngrabsaco-jig-studio'||next.build?.appId!==pkg.build.appId||next.version!==version)
  throw Error('Downloaded update does not match its version or application identity.');
 const target=next.build.files;
 if(!Array.isArray(target)||target.length>120||new Set(target).size!==target.length||!target.every(permittedFile))
  throw Error('The update has an invalid application file list.');
 // Never allow an online source patch to remove existing app files. Additions
 // must be named in the signed-by-checksum owner manifest and explicitly fetched.
 const before=new Set(existing),after=new Set(target);
 if(existing.some(name=>!after.has(name)))throw Error('An online source update cannot remove installed app files. Use an official full installer for this change.');
 for(const name of target)if(!before.has(name)&&!entries.has(name))
  throw Error('Update adds an app file without an authenticated download: '+name);
 for(const name of entries.keys())if(!after.has(name))throw Error('Update includes an unapproved app file: '+name);
 const origConfig={...pkg.build},newConfig={...next.build};
 delete origConfig.files;delete newConfig.files;
 if(JSON.stringify(newConfig)!==JSON.stringify(origConfig))
  throw Error('Online updates may not change the app installer permissions or configuration.');
 const staging=path.join(os.tmpdir(),'jigstudio-owner-source-'+randomUUID());
 const stageApp=path.join(staging,'App');
 const zip=path.join(os.tmpdir(),'jigstudio-owner-update-'+randomUUID()+'.zip');
 try{
  await fs.mkdir(stageApp,{recursive:true,mode:0o700});
  for(const name of existing){
   const source=path.join(baseDirectory,name),destination=path.join(stageApp,name);
   const meta=await fs.lstat(source);
   if(!meta.isFile()||meta.isSymbolicLink())throw Error('Installed app contains an unexpected file type.');
   await fs.mkdir(path.dirname(destination),{recursive:true});
   await fs.copyFile(source,destination);
  }
  for(const part of manifest.files){
   const destination=path.join(stageApp,part.path);
   await fs.mkdir(path.dirname(destination),{recursive:true});
   await fs.writeFile(destination,await fetchVerified(part),{mode:0o600});
  }
  await packageZip(stageApp,zip);
  return zip;
 }catch(error){await fs.rm(zip,{force:true});throw error;}
 finally{await fs.rm(staging,{recursive:true,force:true});}
}

module.exports={prepare,packageZip,crc32,permittedFile};
