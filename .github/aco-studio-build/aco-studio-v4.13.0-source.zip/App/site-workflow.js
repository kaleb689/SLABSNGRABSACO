'use strict';
// Small, deterministic, portable profile-draft engine. No retailer calls or payment secrets.
// Live website writes are exclusively handled by its existing authenticated endpoints.
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  if(root)root.JigSiteWorkflow=api;
})(typeof window!=='undefined'?window:null,function(){
  const GROUPS=Object.freeze([
    {id:'street',label:'Street suffix formatting',section:'line1',description:'Use established street-type abbreviations',exampleBefore:'100 Example Avenue',exampleAfter:'100 Example Ave',safe:true},
    {id:'direction',label:'Compass directions',section:'line1',description:'Standardize written or abbreviated directions',exampleBefore:'100 Northwest Example Drive',exampleAfter:'100 NW Example Drive',safe:true},
    {id:'ordinal',label:'Street number ordinals',section:'line1',description:'Use a recognized numeric street ordinal',exampleBefore:'100 2 Street',exampleAfter:'100 2nd Street',safe:true},
    {id:'unit',label:'Existing unit designators',section:'line2',description:'Keep the real unit identifier, changing only its label',exampleBefore:'Apartment 4B',exampleAfter:'Unit 4B',safe:true},
    {id:'zip',label:'Verified ZIP+4 formatting',section:'postal',description:'Only use actual postal ZIP digits; never generate the extra four',exampleBefore:'12345-6789 (verified)',exampleAfter:'12345',safe:true},
    {id:'city',label:'Verified mailing-city aliases',section:'postal',description:'Use a mailing-city alternative only when verified for that exact address',exampleBefore:'Example City',exampleAfter:'USPS-verified alternate city',safe:true},
    {id:'fraction',label:'Fractional house number',section:'advanced',description:'Add 1/2 to a whole-number house in local draft profiles',exampleBefore:'100 Example St',exampleAfter:'100 1/2 Example St',safe:false,experimental:true},
    {id:'alphanumeric',label:'Alphanumeric house number',section:'advanced',description:'Append A after the house number in a local draft',exampleBefore:'100 Example St',exampleAfter:'100A Example St',safe:false,experimental:true},
    {id:'prefix',label:'Generated three-letter prefix',section:'advanced',description:'Prefix the address line with a reproducible three-letter code',exampleBefore:'100 Example St',exampleAfter:'ABC 100 Example St',safe:false,experimental:true},
    {id:'typo',label:'Double letters / misspellings',section:'advanced',description:'Double a letter in the street name',exampleBefore:'100 Example Lane',exampleAfter:'100 Exammple Lane',safe:false,experimental:true},
    {id:'fictitious',label:'Custom secondary unit',section:'advanced',description:'Set a secondary unit on the local draft profile',exampleBefore:'100 Example St',exampleAfter:'100 Example St, Apt 999',safe:false,experimental:true},
    {id:'fabricatedzip',label:'Custom ZIP+4 suffix',section:'advanced',description:'Add a local draft ZIP+4 suffix',exampleBefore:'ZIP 12345',exampleAfter:'ZIP 12345-0000',safe:false,experimental:true}
  ]);
  const pairs=[['AVENUE','AVE'],['STREET','ST'],['DRIVE','DR'],['BOULEVARD','BLVD'],['ROAD','RD'],['LANE','LN'],['TERRACE','TER'],['PLACE','PL'],['COURT','CT'],['CIRCLE','CIR'],['PARKWAY','PKWY'],['WAY','WY']];
  const dirs=[['NORTHWEST','NW'],['NORTHEAST','NE'],['SOUTHWEST','SW'],['SOUTHEAST','SE'],['NORTH','N'],['SOUTH','S'],['EAST','E'],['WEST','W']];
  const unitPattern=/^(?:(APT|APARTMENT|UNIT|SUITE|STE|#)\s*#?\s*)([A-Z\d][A-Z\d-]*)$/i;
  const clear=value=>String(value??'').replace(/\s+/g,' ').trim();
  const canonical=value=>clear(value).toUpperCase();
  const phoneTools=typeof Verification!=='undefined'?Verification:(typeof require==='function'?require('./verification'):null);
  function phoneOf(v={}){
    for(const key of ['phone','phoneNumber','phone_num','phone_number','mobile','mobilePhone','telephone','contactPhone']){
      if(clear(v[key]))return clear(v[key]);
    }
    return clear(v.contact?.phone||v.contact?.phoneNumber);
  }
  function postal(v={}){return {
    firstName:clear(v.firstName),lastName:clear(v.lastName),phone:phoneOf(v),
    address:clear(v.address||v.address1||v.addressLine1),address2:clear(v.address2||v.addressLine2),
    city:clear(v.city),state:clear(v.state),zip:clear(v.zip||v.zipCode),country:clear(v.country||v.countryCode||'US')
  };}
  function changeLine(value,from,to){
    const words=clear(value).split(/\s+/);const last=words.length-1;
    if(canonical(words[last])===from){words[last]=to;return words.join(' ')}
    return value;
  }
  function transform(base,group,variantIndex){
    const p=postal(base),mode=variantIndex%3;
    if(group==='street'){
      for(const [long,short] of pairs){
        const a=changeLine(p.address,long,short),b=changeLine(p.address,short,long);
        if(canonical(a)!==canonical(p.address)||a!==p.address){p.address=a;return p}
        if(canonical(b)!==canonical(p.address)||b!==p.address){p.address=b;return p}
      }
    }
    if(group==='direction'){
      for(const [long,short] of dirs){
        const before=p.address;
        const match=before.match(/^([\dA-Z/-]+\s+)([A-Za-z]+)(\s+.+)$/);
        if(match&&[long,short].includes(canonical(match[2]))){
          p.address=match[1]+(canonical(match[2])===long?short:long)+match[3];
          return p;
        }
      }
    }
    if(group==='ordinal'){
      const match=p.address.match(/^(\d+[A-Za-z/-]*\s+(?:(?:NW|NE|SW|SE|N|S|E|W)\s+)?)(\d{1,3})(ST|ND|RD|TH)?(?=\s)/i);
      if(match){
        const n=Number(match[2]);const suffix=(n%100>=11&&n%100<=13?'TH':({1:'ST',2:'ND',3:'RD'}[n%10]||'TH'));
        const v=match[3]?match[2]:match[2]+suffix;
        p.address=match[1]+v+p.address.slice(match[0].length);return p;
      }
    }
    if(group==='unit'&&p.address2){
      const match=p.address2.match(unitPattern);
      if(match){const label=['UNIT','APT','STE'][mode];if(label!==canonical(match[1]))p.address2=label+' '+match[2];else p.address2='# '+match[2];return p}
    }
    if(group==='zip'){
      // ZIP+4 must come from the saved address, never a generated number.
      if(/^\d{5}-\d{4}$/.test(p.zip)){p.zip=p.zip.slice(0,5);return p}
    }
    if(group==='city'&&base.verifiedAlternateCity===true&&clear(base.alternateCity)){
      p.city=clear(base.alternateCity);return p;
    }
    // These are deliberate, local-only draft transformations. They are not
    // sent to the website's linked-account/address update endpoint.
    if(group==='fraction'){
      const next=fractionalPreview(p.address);if(next)p.address=next;return p;
    }
    if(group==='alphanumeric'){
      const match=p.address.match(/^(\d{1,7})(\s+.+)$/);if(match)p.address=match[1]+'A'+match[2];return p;
    }
    if(group==='prefix'){
      const original=p.address;
      if(original&&!/^[A-Z]{3}\s/.test(original)){
        let hash=2166136261;
        for(const ch of original+'|'+mode){hash=Math.imul(hash^ch.charCodeAt(0),16777619);}
        let value=hash>>>0,token='';
        for(let i=0;i<3;i++){token=String.fromCharCode(65+(value%26))+token;value=Math.floor(value/26);}
        p.address=token+' '+original;
      }
      return p;
    }
    if(group==='typo'){
      const match=p.address.match(/^(\d+[A-Za-z/-]*\s+)([A-Za-z]{5,})(.*)$/);
      if(match){const word=match[2],at=Math.min(word.length-2,Math.max(1,Math.floor(word.length/2)));
        p.address=match[1]+word.slice(0,at)+word[at]+word.slice(at)+match[3];}
      return p;
    }
    if(group==='fictitious'){
      p.address2=['APT 999','UNIT 998','STE X9'][mode];return p;
    }
    if(group==='fabricatedzip'){
      if(/^\d{5}(?:-\d{4})?$/.test(p.zip))p.zip=p.zip.slice(0,5)+'-'+String(mode).padStart(4,'0');
      return p;
    }
    return p;
  }
  function fractionalPreview(address){
    const text=clear(address),match=text.match(/^(\d{1,7})\s+(\S.*)$/);
    if(!match || /^(?:\d+\s*\/\s*\d+|½)(?:\s|$)/.test(match[2]) || !/^[A-Za-z0-9]/.test(match[2]))return '';
    return match[1]+' 1/2 '+match[2];
  }
  function fingerprint(v){const a=postal(v);return [a.address,a.address2,a.city,a.state,a.zip,a.country].map(canonical).join('|')}
  function candidateFor(source,priorSet,groups,combine,step){
    const allowed=groups.filter(x=>GROUPS.some(g=>g.id===x));
    if(!allowed.length)return null;
    const variants=[];
    for(let i=0;i<allowed.length;i++){
      const first=allowed[(step+i)%allowed.length];
      variants.push([first]);
      if(combine&&allowed.length>1){
        const second=allowed[(step+i+1)%allowed.length];
        if(second!==first)variants.push([first,second]);
      }
    }
    for(const groupSequence of variants){let v={...source};for(const g of groupSequence)v={...v,...transform(v,g,step)};
      const k=fingerprint(v);if(k!==fingerprint(source)&&!priorSet.has(k))return {value:postal(v),applied:groupSequence,key:k};
    }
    return null;
  }
  function create(input={}){
    const count=Number(input.count),limit=Number(input.limit);
    if(!Number.isSafeInteger(count)||count<1||count>100)throw Error('Choose 1 to 100 profiles.');
    if(!Number.isSafeInteger(limit)||limit<1||count>limit)throw Error('Profile quantity must not exceed the customer membership allowance.');
    const shipping=(Array.isArray(input.shipping)?input.shipping:[]).map(postal).filter(x=>x.address&&x.city&&x.state&&x.zip);
    const billing=(Array.isArray(input.billing)?input.billing:[]).map(postal).filter(x=>x.address&&x.city&&x.state&&x.zip);
    if(!shipping.length)throw Error('Select at least one complete, real shipping address.');
    if(!billing.length&&!input.sameBilling)throw Error('Select a billing address or enable billing same as shipping.');
    const cards=Array.isArray(input.cards)?input.cards:[];
    const groups=Array.isArray(input.groups)?input.groups:[];
    const names=Array.isArray(input.names)?input.names:[];
    const linked=(Array.isArray(input.linked)?input.linked:[]).filter(x=>x?.active===true);
    const fingerprints=new Set(),counts=new Map(),rows=[];
    for(let i=0;i<count;i++){
      const source=shipping[i%shipping.length],baseKey=fingerprint(source),used=counts.get(baseKey)||0;
      counts.set(baseKey,used+1);
      const attempt=used?candidateFor(source,fingerprints,groups,input.combine===true,i):null;
      const ship={...source,...(attempt?.value||{})};
      const id=fingerprint(ship);fingerprints.add(id);
      const bill=input.sameBilling?{...ship}:{...billing[i%billing.length]};
      const match=clear(names[i]||'').match(/^(.+?)\s+([^\s]+)$/);
      if(match){ship.firstName=match[1];ship.lastName=match[2];if(input.sameBilling){bill.firstName=match[1];bill.lastName=match[2]}}
      const card=cards.length?cards[i%cards.length]:null;
      const fractionalSuggestion=groups.includes('fraction')&&used>0&&!attempt?.applied.includes('fraction')?fractionalPreview(source.address):'';
      rows.push({slot:i+1,retailer:clear(input.retailer),name:clear(input.customerName)+' '+(i+1),shipping:ship,billing:bill,
        cardRef:card?{id:clear(card.id),label:clear(card.label||card.cardLabel),brand:clear(card.brand),last4:clear(card.last4)}:null,
        linked:linked[i]||null,email:clear(linked[i]?.loginEmail||''),phone:ship.phone,
        changed:!!attempt,unchanged:!attempt,applied:attempt?.applied||[],
        needsReview:(used>0&&!attempt)||!!fractionalSuggestion||!!attempt?.applied.some(id=>GROUPS.find(g=>g.id===id)?.experimental),
        fractionalSuggestion, fractionalVerified:false, sourceAddressIndex:i%shipping.length});
    }
    if(input.jigPhones===true){
      if(!phoneTools?.jigPhone)throw Error('The phone jig helper is not available.');
      const seen=new Set(rows.map(x=>x.phone).filter(Boolean).map(x=>phoneTools.phoneKey(x)));
      for(const row of rows){
        if(!row.phone)continue; // Do not invent a number for a missing contact field.
        row.phone=phoneTools.jigPhone(row.phone,seen);
        row.shipping.phone=row.phone;
        if(input.sameBilling)row.billing.phone=row.phone;
        row.phoneJigged=true;
      }
    }
    return rows;
  }
  return Object.freeze({GROUPS,postal,fingerprint,fractionalPreview,transform,create});
});
