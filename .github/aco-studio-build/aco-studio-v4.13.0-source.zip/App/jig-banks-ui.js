/* ACO Studio: two strictly separated local address banks; one-to-one Personal Card Pool. */
(()=>{'use strict';
 const d=document,$=id=>d.getElementById(id),jig=window.desktopAPI?.jigBanks;
 const personal=window.desktopAPI?.personalCards,importer=()=>window.JigStudioLocalImport;
 const s={scope:'personal',customerId:null,addresses:[],selected:new Set(),busy:false,cardItems:[],cardAssignments:[],assignmentImportKey:null};
 if(!jig||!personal||!$('studioJigBanks'))return;
 const msg=(value,error=false)=>{const el=$('jigBanksStatus');el.textContent=value;el.classList.toggle('jigBankError',error);};
 const context=()=>importer()?.bankTargets?.()||null;
 const allowed=scope=>{const ctx=context();return !ctx||ctx.scope===scope;};
 function renderMemberBind(){
  const ctx=context(),bind=$('jigAcoBind'),select=$('jigAcoMemberPick');
  bind.hidden=!ctx||ctx.isWebsiteImport;
  const prior=select.value;
  const members=(window.JigWebsiteCustomers?.list?.()||[]).filter(c=>Number(c.tierCount)>0);
  select.replaceChildren(new Option(members.length?'Choose an ACO membership customer':'Sign in to website Admin to load memberships',''));
  for(const c of members)select.append(new Option(c.name+' · '+c.email+' · '+c.tierCount+' profiles',c.id));
  select.value=members.some(c=>c.id===prior)?prior:(members.some(c=>c.id===ctx?.customerId)?ctx.customerId:'');
  $('jigBindMember').disabled=!ctx||ctx.isWebsiteImport||!members.length;
  $('jigUnbindMember').disabled=!ctx||ctx.isWebsiteImport||ctx.scope!=='aco';
 }
 function setButtons(){
  const ctx=context(),aco=s.scope==='aco',ok=!!ctx&&ctx.scope===s.scope&&(!aco||ctx.customerId===s.customerId);
  $('personalJigScope').setAttribute('aria-pressed',String(!aco));$('acoJigScope').setAttribute('aria-pressed',String(aco));
  $('personalJigScope').disabled=!!ctx&&ctx.scope!=='personal';$('acoJigScope').disabled=!!ctx&&ctx.scope!=='aco';
  $('personalCardBank').hidden=aco;
  $('bankImport18').hidden=aco;$('bankImport18').disabled=s.busy;
  $('bankAddAddress').disabled=s.busy||(aco&&!s.customerId);
  $('bankSelectAll').disabled=!s.addresses.length;$('bankSelectNone').disabled=!s.addresses.length;
  $('bankApplyAddresses').disabled=!ok||!s.selected.size||s.busy;
  $('bankClearAssignment').disabled=!ok||!ctx?.bankApplied;
  const source=ctx?.name||'No profile file selected';
  $('jigBankSource').textContent=ctx?(aco?'ACO membership customer '+ctx.customerId+' · ': 'Personal local import · ')+source+' · '+ctx.indices.length+' selected profile(s)':'No profile file selected. Personal Jigs apply to local files; ACO Jigs require importing a website membership customer.';
  $('personalBankExport').disabled=!ctx||ctx.scope!=='personal'||!s.cardAssignments.length||s.cardAssignments.length!==ctx.count||s.assignmentImportKey!==ctx.importKey;
 }
 function safeAddressText(a){return [a.address1,a.address2,[a.city,a.state,a.zip].filter(Boolean).join(' ')].filter(Boolean).join(' · ');}
 function showList(){
  const list=$('jigBanksList');list.replaceChildren();
  if(!s.addresses.length){const empty=d.createElement('div');empty.className='jigBankEmpty';empty.textContent=s.scope==='personal'?'No Personal addresses saved yet. Import your private 18-address file or add an address.':'No addresses saved for this membership customer. First load their saved website information.';list.append(empty);}
  for(const address of s.addresses){
   const row=d.createElement('div');row.className='jigBankAddress';const label=d.createElement('label');
   const cb=d.createElement('input');cb.type='checkbox';cb.checked=s.selected.has(address.id);
   cb.addEventListener('change',()=>{if(cb.checked)s.selected.add(address.id);else s.selected.delete(address.id);setButtons();});
   const data=d.createElement('span'),title=d.createElement('strong'),note=d.createElement('small');
   title.textContent=address.label||'Address';note.textContent=safeAddressText(address);data.append(title,note);label.append(cb,data);
   const status=d.createElement('span');status.className='jigBankType';status.textContent=address.source==='website'?'WEBSITE':'LOCAL';row.append(label,status);
   if(address.source!=='website'){
    const remove=d.createElement('button');remove.type='button';remove.className='btn slim plain';remove.textContent='Remove';
    remove.addEventListener('click',async()=>{
     if(!confirm('Remove this '+s.scope+' address from the encrypted bank?'))return;
     try{
      if(s.scope==='personal')await jig.personal.remove(address.id);
      else await jig.aco.remove(s.customerId,address.id);
      await refresh();msg('Address removed from this bank only. Imported profiles and website records were not changed.');
     }catch(e){msg(e.message,true);}
    });row.append(remove);
   }
   list.append(row);
  }
  setButtons();
 }
 async function refresh(){
  if(s.busy)return;
  const ctx=context(),scope=s.scope,customerId=scope==='aco'?ctx?.customerId:null;
  if(scope==='aco'&&!customerId){s.addresses=[];s.selected.clear();s.customerId=null;showList();return;}
  s.customerId=customerId;
  try{
   const data=scope==='personal'?await jig.personal.list():await jig.aco.list(customerId);
   if(s.scope!==scope||s.customerId!==customerId)return;
   s.addresses=data.addresses||[];s.selected=new Set([...s.selected].filter(id=>s.addresses.some(x=>x.id===id)));
   showList();
  }catch(e){s.addresses=[];s.selected.clear();showList();msg(e.message,true);}
 }
 async function changeContext(){
  const ctx=context();s.scope=ctx?.scope||'personal';s.customerId=ctx?.scope==='aco'?ctx.customerId:null;
  s.selected.clear();$('jigBankAddressForm').hidden=true;await refresh();if(s.scope==='personal')await refreshPersonalCards();
  renderMemberBind();setButtons();
 }
 async function changeScope(scope){
  if(!allowed(scope)){msg('This imported file is '+context().scope+'. To use '+scope+', select the matching profile source. Banks cannot mix.',true);return;}
  s.scope=scope;s.customerId=scope==='aco'?context()?.customerId:null;s.selected.clear();await refresh();
  msg(scope==='personal'?'Personal bank selected. ACO records are inaccessible here.':'ACO bank selected. Personal addresses and cards are inaccessible here.');
 }
 $('jigBindMember').addEventListener('click',async()=>{
  try{
   const customerId=$('jigAcoMemberPick').value;
   const member=window.JigWebsiteCustomers?.list?.().find(c=>c.id===customerId&&Number(c.tierCount)>0);
   if(!member)throw Error('Select a customer with a current membership and sign in to Admin first.');
   // Obtain the selected customer's addresses only from their authorized website
   // record; no local Personal bank address is ever read here.
   const detail=await window.JigWebsiteCustomers.detail(customerId);
   const addresses=(detail.saved?.addresses||[]).filter(a=>Boolean(a?.address||a?.addressLine1||a?.address1)&&a.city&&a.state&&(a.zip||a.zipCode));
   if(!addresses.length&&detail.customer?.shipping?.address)addresses.push(detail.customer.shipping);
   await jig.aco.sync(customerId);
   importer().bindLocalImportToMember(customerId);
   msg('Bound this imported file to '+member.name+' ACO address bank. Any prior Personal overlay was cleared; no addresses or cards were transferred.');
  }catch(e){msg(e.message,true);}
 });
 $('jigUnbindMember').addEventListener('click',()=>{
  try{importer().bindLocalImportToMember(null);msg('Restored this local file to Personal. ACO bank records remain untouched.');}
  catch(e){msg(e.message,true);}
 });
 $('personalJigScope').addEventListener('click',()=>void changeScope('personal'));
 $('acoJigScope').addEventListener('click',()=>void changeScope('aco'));
 $('bankSelectAll').addEventListener('click',()=>{s.selected=new Set(s.addresses.map(a=>a.id));showList();});
 $('bankSelectNone').addEventListener('click',()=>{s.selected.clear();showList();});
 $('bankImport18').addEventListener('click',async()=>{
  if(s.scope!=='personal')return msg('Only Personal Jigs can import the private owner address list.',true);
  try{const result=await jig.personal.import();if(result?.cancelled)return;
   await refresh();msg(result.count+' private Personal addresses available in your encrypted Mac/Windows bank.');}
  catch(e){msg(e.message,true);}
 });
 $('bankAddAddress').addEventListener('click',()=>{$('jigBankAddressForm').hidden=false;$('jigBankAddressForm').elements.label.focus();});
 $('bankCancelAddress').addEventListener('click',()=>{$('jigBankAddressForm').hidden=true;$('jigBankAddressForm').reset();});
 $('jigBankAddressForm').addEventListener('submit',async e=>{
  e.preventDefault();const form=e.currentTarget,data=Object.fromEntries(new FormData(form));
  try{
   if(s.scope==='personal')await jig.personal.add(data);
   else{if(!s.customerId)throw Error('Import a membership customer to add their ACO address.');await jig.aco.add(s.customerId,data);}
   form.reset();form.hidden=true;await refresh();msg('Added address to '+s.scope+' bank only. No other bank or website was changed.');
  }catch(e){msg(e.message,true);}
 });
 $('bankApplyAddresses').addEventListener('click',()=>{
  const ctx=context();try{
   if(!ctx||ctx.scope!==s.scope||(s.scope==='aco'&&ctx.customerId!==s.customerId))throw Error('This profile file belongs to a different address bank.');
   const addresses=s.addresses.filter(a=>s.selected.has(a.id));
   importer().applyBankSelection({scope:s.scope,customerId:s.scope==='aco'?s.customerId:null,addresses,
    mirrorBilling:$('bankMirrorBilling').checked});
   setButtons();msg('Applied '+addresses.length+' '+s.scope+' address(es) to '+ctx.indices.length+' selected profiles. Review the before/after jig preview before export.');
  }catch(e){msg(e.message,true);}
 });
 $('bankClearAssignment').addEventListener('click',()=>{
  try{importer().applyBankSelection(null);setButtons();msg('Removed address bank overlay from this profile file. Original import is unchanged.');}
  catch(e){msg(e.message,true);}
 });
 // A separate modal for the owner's OS-encrypted personal cards. Only masked data
 // crosses IPC. Every profile must get a different card; no round-robin reuse.
 const modal=d.createElement('div');modal.className='jigPersonalCardsModal';modal.hidden=true;modal.setAttribute('role','dialog');modal.setAttribute('aria-modal','true');modal.setAttribute('aria-label','Personal card pool');
 modal.innerHTML=`<div class="jigPersonalCardsBox"><div class="jigPersonalCardsHeader"><div><span class="eyebrow">PERSONAL ONLY • OS ENCRYPTED</span><h2>Personal Card Pool · 1:1</h2><p>Save cards to your personal vault only. They never appear in ACO customer banks.</p></div><button id="jigPersonalCardsClose" type="button" class="btn plain slim">Close ✕</button></div>
 <form id="jigPersonalCardForm" autocomplete="off"><label>Card label<input name="label" maxlength="70" placeholder="Personal card 1" required autocomplete="off"></label><label>Cardholder<input name="cardholder" maxlength="120" required autocomplete="off"></label><label>Card number<input name="number" inputmode="numeric" maxlength="26" required autocomplete="off"></label><label>Expiry month<input name="expMonth" inputmode="numeric" maxlength="2" placeholder="MM" required autocomplete="off"></label><label>Expiry year<input name="expYear" inputmode="numeric" maxlength="4" placeholder="YYYY" required autocomplete="off"></label><label>Brand<select name="brand"><option>Visa</option><option>Mastercard</option><option>American Express</option><option>Discover</option><option>Other</option></select></label><label>Custom security/reference code (NOT CVV/CVC/CID)<input name="customCode" type="password" maxlength="64" autocomplete="off" placeholder="Optional personal project code"></label><button type="submit" class="btn primary">+ Save encrypted personal card</button></form>
 <p class="jigBankCardWarning">Your optional custom code is stored encrypted but not exported as a payment verification code. Do not enter CVV/CVC/CID.</p>
 <div class="jigCardsRows" id="jigPersonalCardsRows"></div><h3>Assign one different card per profile</h3><div id="jigPersonalCardSlots" class="jigCardSlotRows"></div><div class="buttons"><button type="button" class="btn primary" id="jigCardsSaveAssignments">Save unique 1:1 assignments</button></div><p id="jigPersonalCardStatus" role="status"></p></div>`;
 d.body.append(modal);
 const cardMsg=(value,error=false)=>{const node=$('jigPersonalCardStatus');node.textContent=value;node.classList.toggle('jigBankError',error);};
 function cardRows(){
  const list=$('jigPersonalCardsRows');list.replaceChildren();
  for(const card of s.cardItems){
   const row=d.createElement('div');row.className='jigSavedCard';const text=d.createElement('span');
   text.textContent=[card.label,card.brand,card.cardholder,'•••• '+card.last4,card.hasCustomCode?'custom code saved':null].filter(Boolean).join(' · ');
   const b=d.createElement('button');b.type='button';b.className='btn slim plain';b.textContent='Remove';
   b.addEventListener('click',async()=>{if(!confirm('Remove this personal card from this device?'))return;try{await personal.remove(card.id);await refreshPersonalCards();}catch(e){cardMsg(e.message,true);}});
   row.append(text,b);list.append(row);
  }
  const slots=$('jigPersonalCardSlots');slots.replaceChildren();const ctx=context();
  if(!ctx||ctx.scope!=='personal'){slots.textContent='Import a Personal profile file first.';return;}
  if(ctx.count>500){slots.textContent='Up to 500 personal card assignments are supported per file.';return;}
  for(let i=0;i<ctx.count;i++){
   const wrap=d.createElement('label');wrap.className='jigCardSlot';wrap.textContent='Profile '+(i+1);
   const select=d.createElement('select');select.dataset.slot=String(i+1);select.append(new Option('Choose a unique card',''));
   for(const card of s.cardItems)select.append(new Option(card.label+' · •••• '+card.last4,card.id));
   const assigned=s.assignmentImportKey===ctx.importKey?s.cardAssignments.find(x=>x.slot===i+1):null;if(assigned&&s.cardItems.some(c=>c.id===assigned.cardId))select.value=assigned.cardId;
   wrap.append(select);slots.append(wrap);
  }
 }
 function renderCardPreview(){
  const wrap=$('personalCardAssignmentsPreview');wrap.replaceChildren();const ctx=context();
  if(!ctx||ctx.scope!=='personal')return;
  const good=s.cardAssignments.length===ctx.count&&s.cardAssignments.length>0&&s.assignmentImportKey===ctx.importKey;
  const title=d.createElement('strong');title.textContent=good?ctx.count+' distinct saved card assignments for this personal import':s.cardItems.length+' personal card(s) saved; assign '+ctx.count+' unique cards for 1:1 export.';
  wrap.append(title);
  if(good){const list=d.createElement('div');list.className='jigCardPreviewGrid';for(const a of s.cardAssignments.slice(0,100)){
   const card=s.cardItems.find(c=>c.id===a.cardId),row=d.createElement('small');row.textContent='Profile '+a.slot+' → '+(card?.label||'Card')+' •••• '+(card?.last4||a.last4);list.append(row);
  }wrap.append(list);}
  setButtons();
 }
 async function refreshPersonalCards(){
  if(!personal)return;
  try{const data=await personal.list();s.cardItems=data.cards||[];s.cardAssignments=data.assignments||[];s.assignmentImportKey=data.assignmentImportKey||null;cardRows();renderCardPreview();}
  catch(e){s.cardItems=[];s.cardAssignments=[];s.assignmentImportKey=null;cardMsg(e.message,true);renderCardPreview();}
 }
 function closeCards(){modal.hidden=true;$('jigPersonalCardForm').reset();}
 $('openPersonalCardPool').addEventListener('click',async()=>{if(context()?.scope!=='personal'){msg('Personal card pool is only available for personal profile files.',true);return;}modal.hidden=false;await refreshPersonalCards();$('jigPersonalCardsClose').focus();});
 $('jigPersonalCardsClose').addEventListener('click',closeCards);modal.addEventListener('click',event=>{if(event.target===modal)closeCards();});
 d.addEventListener('keydown',event=>{if(!modal.hidden&&event.key==='Escape')closeCards();});
 $('jigPersonalCardForm').addEventListener('submit',async e=>{
  e.preventDefault();const form=e.currentTarget;
  try{await personal.add(Object.fromEntries(new FormData(form)));form.reset();await refreshPersonalCards();cardMsg('Personal card and optional non-payment custom code saved in the OS-encrypted personal vault.');}
  catch(e){cardMsg(e.message,true);}
 });
 $('jigCardsSaveAssignments').addEventListener('click',async()=>{
  try{const ctx=context();if(!ctx||ctx.scope!=='personal')throw Error('This profile file does not belong to your personal bank.');
   const ids=[...$('jigPersonalCardSlots').querySelectorAll('select')].map(x=>x.value);
   if(!ids.length||ids.some(x=>!x)||new Set(ids).size!==ids.length)throw Error('Choose a different saved personal card for every profile.');
   await personal.assign(ids,ctx.count,ctx.importKey);await refreshPersonalCards();cardMsg('Saved '+ids.length+' unique personal card-to-profile assignments. Nothing was uploaded to your website.');
  }catch(e){cardMsg(e.message,true);}
 });
 $('personalBankExport').addEventListener('click',async()=>{
  try{const ctx=context();if(!ctx||ctx.scope!=='personal'||s.cardAssignments.length!==ctx.count||s.assignmentImportKey!==ctx.importKey)throw Error('Save unique 1:1 personal card assignments for this imported file first.');
   const file=importer().currentPersonalExport();
   if(!confirm('This will save full personal card numbers into a UNENCRYPTED local Shikari/Valor file. Your custom project security code remains encrypted; no CVV is exported. Continue?'))return;
   const result=await personal.exportProfiles({scope:'personal',fileName:file.fileName,records:file.records,importKey:ctx.importKey,confirmUnencryptedExport:true});
   msg(result?.saved?'Saved personal profile file '+result.name+' with '+result.assigned+' unique card assignments.':'Export cancelled.');
  }catch(e){msg(e.message,true);}
 });
 d.addEventListener('jigstudio:bank-context-updated',()=>{closeCards();void changeContext();});
 d.addEventListener('jigstudio:aco-addresses-synced',()=>{if(s.scope==='aco')void refresh();});
 void changeContext();
})();
