'use strict';
const {contextBridge,ipcRenderer}=require('electron');
if(location.origin==='https://slabsngrabsaco.com'){
 contextBridge.exposeInMainWorld('jigSignals',Object.freeze({changed:()=>ipcRenderer.send('site:remote-change')}));
}
