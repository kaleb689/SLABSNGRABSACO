# ACO Studio v4.13.0 — technical build notes

This is **development source**, not a first-time installer. The owner must NOT need Node.js, npm or Terminal to install and run the finished Mac application. Distribute a pre-built signed/notarized `.dmg` with the Electron runtime bundled.

The app package identity remains `com.slabsngrabsaco.jigstudio.owner` to preserve compatibility and device-local OS-encrypted data. The window is branded **SLABSNGRABSACO ACO Studio**.

## Build on an Apple macOS machine or a macOS GitHub Actions runner

`npm install --no-audit --no-fund` and `npm run check`, then `npx electron-builder --mac dmg zip --x64 --arm64 --publish never` from `App/`. These are **developer/CI instructions** and must NOT be run on the owner's computer. A prepared `.github/workflows/build-mac-aco-studio.yml` is included with the development archive but has not been executed. Unsigned installers can trigger Gatekeeper; production releases require a signing certificate and notarization.

## Functionality and security contracts

* Personal Jigs uses `personal-jigs.bank.encrypted`; ACO Jigs uses `aco-jigs-by-customer.bank.encrypted`, keyed by the currently authorized membership customer's website ID. ACO website data fetch happens **inside the main Electron process**. Personal address-bank values are not accepted as website-sync input. Reusing a bank across different customers is rejected.
* `PERSONAL_18_PRIVATE_IMPORT.json` belongs **only in the private owner's download**, outside source/GitHub, and contains the 18 previously used main addresses without cards/logins. Import to encrypt with Electron safeStorage. Delete the plaintext import once saved.
* Personal Card Pool uses `jig-studio-personal-cards.encrypted`, separate from the original ACO-local `jig-studio-local-cards.encrypted`. Exactly one unique card per profile; 1:1 selection is tied to an import session, not reused across subsequent files. Encrypted custom **non-CVV** reference data is allowed; CVV/CVC/CID is blocked and never exported.
* Local card-number exports **create unencrypted files** only after an explicit confirmation. Never upload these to GitHub, cloud logs or website success feeds. Website card methods remain sanitized/masked as previously implemented.
* Existing complete website Admin fallback is retained for not-yet-migrated functions. No automatic website write is implied by a local JIG export.

## Checks

`npm run check` currently covers 13 tests; private 18-address bank import was separately tested. Live UI, Keychain, production APIs and macOS installers are not tested in this environment.
