/* User-entered synthetic test cards, allocated evenly to Shikari/Valor profiles.
 * The two panels are isolated, browser-memory-only and never write to website APIs.
 */
(()=>{'use strict';
 const core=window.JigPaymentAllocation;
 if(!core)return;
 const escape=s=>String(s??'').replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
 function attach(scope,mountId,targets,onApply){
  const mount=document.getElementById(mountId);
  if(!mount)return null;
  let cards=[],assignment=null;
  mount.classList.add('cardDist');
  mount.innerHTML=`<div class="cardDistHead"><div><h3>Multiple Cards · Even Distribution</h3><p class="cardDistIntro">Add your synthetic test cards here. Click <b>Distribute evenly</b> to assign them across the selected profiles: Card 1, Card 2, Card 3, then repeat.</p></div><span class="cardDistPill">SESSION-ONLY</span></div>
   <form class="cardDistForm" autocomplete="off">
    <label>Card label<input name="label" maxlength="70" placeholder="Test Card 1"></label>
    <label>Cardholder<input name="cardholder" maxlength="120" placeholder="Test Account" required></label>
    <label>Test card number<input name="number" type="text" inputmode="numeric" maxlength="26" placeholder="Test numbers only" autocomplete="off" required></label>
    <label>Month<input name="month" type="text" inputmode="numeric" maxlength="2" placeholder="MM" required></label>
    <label>Year<input name="year" type="text" inputmode="numeric" maxlength="4" placeholder="YYYY" required></label>
    <label>Test CVV<input name="cvv" type="password" inputmode="numeric" maxlength="4" placeholder="Optional" autocomplete="off"></label>
    <label>Card type<select name="type"><option value="Visa">Visa</option><option value="Mastercard">Mastercard</option><option value="American Express">Amex</option><option value="Discover">Discover</option><option value="">Other</option></select></label>
    <label class="cardDistCheckbox"><input name="synthetic" type="checkbox" required><span>I confirm these are <b>fictional/synthetic test card details only</b>, not live payment-card or security-code information.</span></label>
    <div class="cardDistActions"><button type="submit" class="btn secondary">+ Add another card</button><button class="btn primary cardDistAllocate" type="button">Distribute evenly</button><button class="btn plain cardDistClear" type="button">Clear test cards</button></div>
   </form>
   <div class="cardDistCards" aria-label="Session test cards"></div>
   <div class="cardDistStatus" role="status">No cards entered yet. Add one or more synthetic test cards.</div>
   <div class="cardDistPreview" aria-label="Per-profile card assignments"></div>
   <p class="cardDistSecurity">Synthetic values are held in memory while this app is open. They are never saved to Jig Studio settings, Email Bank, your website or notifications. <b>Downloaded Shikari/Valor files are unencrypted</b> and will contain the test card fields. Never enter or export real CVVs here.</p>`;
  const form=mount.querySelector('form'),list=mount.querySelector('.cardDistCards'),preview=mount.querySelector('.cardDistPreview'),message=mount.querySelector('.cardDistStatus');
  const say=(value,error=false)=>{message.textContent=value;message.classList.toggle('error',error);};
  function draw(){
   list.replaceChildren();
   cards.forEach((c,i)=>{
    const item=document.createElement('div');item.className='cardDistCard';
    const details=document.createElement('span');
    const heading=document.createElement('strong');heading.textContent=c.label;
    const desc=document.createElement('small');desc.textContent=c.cardholder+' · '+(c.type||'Test card')+' •••• '+c.number.slice(-4)+' · '+c.month+'/'+c.year;
    const remove=document.createElement('button');remove.type='button';remove.textContent='✕';remove.setAttribute('aria-label','Remove '+c.label);
    remove.addEventListener('click',()=>{cards.splice(i,1);invalidate();say('Removed test card. Distribute again to update profile assignments.');draw();});
    details.append(heading,desc);item.append(details,remove);list.append(item);
   });
   preview.replaceChildren();
   if(!assignment)return;
   const {count,indices}=targets();
   if(count!==assignment.count || JSON.stringify(indices)!==JSON.stringify(assignment.indices)){
    invalidate();say('Profile selection changed. Click Distribute evenly again to reassign cards.');return;
   }
   for(const item of core.summary(assignment.cards,count,indices).filter(Boolean).slice(0,100)){
    const row=document.createElement('div');row.className='cardDistAssignment';
    const title=document.createElement('b');title.textContent='Profile '+item.slot;
    const sub=document.createElement('small');sub.textContent=item.label+' · •••• '+item.last4;
    row.append(title,sub);preview.append(row);
   }
  }
  function invalidate(){assignment=null;onApply?.(null);}
  function clear(){cards=[];invalidate();form.reset();draw();say('Test card list cleared from the current session.');}
  form.addEventListener('submit',event=>{
   event.preventDefault();
   try{
    if(cards.length>=100)throw Error('Up to 100 test cards are supported.');
    const f=new FormData(form),card=core.normalize(Object.fromEntries([...f.entries(),['synthetic',form.elements.synthetic.checked]]));
    cards.push(card);invalidate();form.reset();draw();say(cards.length+' synthetic test card'+(cards.length===1?'':'s')+' added. Choose Distribute evenly before export.');
   }catch(error){say(error.message||'Could not add the test card.',true);}
  });
  mount.querySelector('.cardDistAllocate').addEventListener('click',()=>{
   try{
    const current=targets();
    if(!current || !Number.isInteger(current.count) || current.count<1)throw Error('Load or create profiles before distributing cards.');
    if(!Array.isArray(current.indices)||!current.indices.length)throw Error('Select at least one profile to receive a test card.');
    if(scope==='studio'&&core.detect(current.records)!==current.format)throw Error('Only Shikari CSV or Valor JSON profiles support synthetic test card assignment.');
    core.even(cards,current.count,current.indices);
    assignment={cards:[...cards],count:current.count,indices:[...current.indices]};
    onApply?.(assignment);draw();say('Evenly distributed '+cards.length+' test card(s) across '+current.indices.length+' selected profile(s). Review the assignments below before export.');
   }catch(error){say(error.message||'Card distribution failed.',true);}
  });
  mount.querySelector('.cardDistClear').addEventListener('click',clear);
  function mapped(){if(!assignment)return null;const curr=targets();if(!curr||curr.count!==assignment.count||JSON.stringify(curr.indices)!==JSON.stringify(assignment.indices))return null;return core.even(assignment.cards,assignment.count,assignment.indices);}
  return Object.freeze({
   clear,resetAssignment(){invalidate();draw();},refresh(){draw();},
   isApplied(){return !!mapped();},
   cardForIndex(index){return mapped()?.[index]||null;},
   assignments(){return mapped();},
   count(){return cards.length;}
  });
 }
 const studio=attach('studio','studioCardDistribution',()=>window.JigStudioLocalImport?.paymentTargets?.()||{count:0,indices:[],records:[],format:null},a=>window.JigStudioLocalImport?.usePaymentAssignment?.(a));
 const site=attach('site','siteCardDistribution',()=>window.JigStudioWebsiteCards?.targets?.()||{count:0,indices:[]},()=>window.dispatchEvent(new CustomEvent('jigstudio:cards-applied',{detail:{scope:'site'}})));
 window.JigStudioCards=Object.freeze({studio,site});
})();
