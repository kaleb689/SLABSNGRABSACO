'use strict';
/**
 * Two physically distinct OS-encrypted address banks. Personal addresses cannot
 * be read through any ACO method; customer A cannot access customer B. Website
 * entries are tied to one authenticated member and can be refreshed from that
 * member's saved shipping details without overwriting local personal records.
 */
const fsDefault=require('node:fs/promises');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const MEMBER_KEY=/^[A-Za-z0-9_-]{1,150}$/;
const asString=v=>String(v??'').trim();
function memberKey(v){const value=asString(v);if(!MEMBER_KEY.test(value))throw Error('A valid membership customer ID is required.');return value;}
function normalizeAddress(v){
 if(!v||typeof v!=='object'||Array.isArray(v))throw Error('Enter an address.');
 const address1=asString(v.address1||v.address||v.addressLine1||v.shipping_street);
 const address2=asString(v.address2||v.addressLine2||v.unit||v.shipping_street_2);
 const city=asString(v.city||v.reference_city||v.shipping_city);
 const state=asString(v.state||v.shipping_state).toUpperCase();
 const zip=asString(v.zip||v.zipCode||v.shipping_zip_code);
 const label=asString(v.label||v.address_group||'Saved address');
 if(!address1||address1.length>160||address2.length>120||!city||city.length>120||!/^[A-Z]{2}$/.test(state)||!/^\d{5}(?:-\d{4})?$/.test(zip))
  throw Error('Address must have a valid street, city, two-letter state, and 5-digit ZIP (optional verified +4).');
 return {label:label.slice(0,100),address1,address2,city,state,zip};
}
function addressKey(a){return [a.address1,a.address2,a.city,a.state,a.zip].map(v=>asString(v).toUpperCase().replace(/\s+/g,' ')).join('|');}
function makeJigBanks({baseDir,safeStorage,fs=fsDefault,uuid=randomUUID,now=()=>new Date().toISOString()}={}){
 if(!baseDir||!safeStorage||typeof safeStorage.isEncryptionAvailable!=='function')throw Error('The OS-encrypted address vault is required.');
 const personalFile=path.join(baseDir,'personal-jigs.bank.encrypted');
 const acoFile=path.join(baseDir,'aco-jigs-by-customer.bank.encrypted');
 let pending=Promise.resolve();
 function requireCrypto(){if(!safeStorage.isEncryptionAvailable())throw Error('Mac Keychain / Windows encrypted storage is unavailable. Address banks were not written.');}
 async function read(file,fallback){
  requireCrypto();try{
   const content=JSON.parse(safeStorage.decryptString(await fs.readFile(file)));
   if(content?.version!==1||!content.data||typeof content.data!=='object')throw Error('Bad vault format');
   return content.data;
  }catch(e){if(e.code==='ENOENT')return fallback;throw Error('Encrypted address bank could not be unlocked; it was not overwritten.');}
 }
 async function write(file,data){
  requireCrypto();await fs.mkdir(baseDir,{recursive:true,mode:0o700});
  const tmp=file+'.'+uuid()+'.tmp';
  try{await fs.writeFile(tmp,safeStorage.encryptString(JSON.stringify({version:1,data})),{mode:0o600,flag:'wx'});await fs.rename(tmp,file);}
  catch(e){await fs.rm(tmp,{force:true}).catch(()=>{});throw e;}
 }
 function exclusive(fn){const next=pending.catch(()=>{}).then(fn);pending=next.then(()=>{},()=>{});return next;}
 function record(v,source){return {id:uuid(),...normalizeAddress(v),source,createdAt:now()};}
 function uniqueMerge(old,inputs,source){
  const out=[...old];const keys=new Set(out.map(addressKey));
  for(const input of inputs){const item=record(input,source),key=addressKey(item);if(keys.has(key))continue;
   if(out.length>=500)throw Error('The bank supports up to 500 addresses.');out.push(item);keys.add(key);
  }return out;
 }
 async function personal(){await pending;return read(personalFile,{addresses:[],updatedAt:null});}
 async function aco(customerId){const id=memberKey(customerId);await pending;
  const data=await read(acoFile,{customers:{}});
  return {customerId:id,addresses:data.customers[id]?.addresses||[],updatedAt:data.customers[id]?.updatedAt||null};
 }
 return Object.freeze({
  async listPersonal(){const d=await personal();return {scope:'personal',addresses:d.addresses,updatedAt:d.updatedAt};},
  async listAco(customerId){return {scope:'aco',...await aco(customerId)};},
  async importPersonal(inputs){return exclusive(async()=>{
   if(!Array.isArray(inputs)||inputs.length<1||inputs.length>500)throw Error('Choose a valid JSON address list (1–500 entries).');
   // Fail atomically if any record is invalid; never import partial mistaken addresses.
   inputs.map(normalizeAddress);const data=await read(personalFile,{addresses:[],updatedAt:null});
   data.addresses=uniqueMerge(data.addresses,inputs,'personal');data.updatedAt=now();
   await write(personalFile,data);return {count:data.addresses.length,imported:inputs.length};
  });},
  async addPersonal(input){return exclusive(async()=>{
   const data=await read(personalFile,{addresses:[],updatedAt:null});
   const next=uniqueMerge(data.addresses,[input],'personal');
   if(next.length===data.addresses.length)throw Error('This address is already in the Personal bank.');
   data.addresses=next;data.updatedAt=now();await write(personalFile,data);return next.at(-1);
  });},
  async removePersonal(addressId){return exclusive(async()=>{
   const data=await read(personalFile,{addresses:[],updatedAt:null});
   const before=data.addresses.length;data.addresses=data.addresses.filter(x=>x.id!==addressId);
   if(before===data.addresses.length)throw Error('Personal address not found.');
   data.updatedAt=now();await write(personalFile,data);return {removed:true};
  });},
  async syncAco(customerId,inputs){const id=memberKey(customerId);return exclusive(async()=>{
   if(!Array.isArray(inputs)||inputs.length>200)throw Error('Invalid customer address snapshot.');
   inputs.map(normalizeAddress);
   const data=await read(acoFile,{customers:{}}),prior=data.customers[id]||{addresses:[]};
   // The website is authoritative for the website-address subset. Retain only
   // this customer's manual additions; no other customer's key is ever touched.
   const own=(prior.addresses||[]).filter(a=>a.source==='aco-manual');
   const previousWebsite=new Map((prior.addresses||[]).filter(a=>a.source==='website').map(a=>[addressKey(a),a]));
   const merged=[...own],keys=new Set(own.map(addressKey));
   for(const input of inputs){
    const normalized=normalizeAddress(input),key=addressKey(normalized);
    if(keys.has(key))continue;
    const saved=previousWebsite.get(key);
    merged.push(saved?{...saved,...normalized,source:'website'}:record(normalized,'website'));
    keys.add(key);
   }
   data.customers[id]={addresses:merged,updatedAt:now()};await write(acoFile,data);
   return {customerId:id,count:merged.length};
  });},
  async addAco(customerId,input){const id=memberKey(customerId);return exclusive(async()=>{
   const data=await read(acoFile,{customers:{}}),prior=data.customers[id]||{addresses:[]};
   const next=uniqueMerge(prior.addresses,[input],'aco-manual');
   if(next.length===prior.addresses.length)throw Error('This address is already saved for this customer.');
   data.customers[id]={addresses:next,updatedAt:now()};await write(acoFile,data);return next.at(-1);
  });},
  async removeAco(customerId,addressId){const id=memberKey(customerId);return exclusive(async()=>{
   const data=await read(acoFile,{customers:{}}),prior=data.customers[id]||{addresses:[]};
   const target=prior.addresses.find(a=>a.id===addressId);
   if(!target)throw Error('Address does not belong to the selected ACO customer.');
   if(target.source==='website')throw Error('Remove a website-saved address on the website; it cannot be deleted from the local ACO bank.');
   data.customers[id]={addresses:prior.addresses.filter(a=>a.id!==addressId),updatedAt:now()};await write(acoFile,data);return {removed:true};
  });}
 });
}
module.exports={makeJigBanks,memberKey,normalizeAddress,addressKey};
