'use strict';
// Owner-only assisted verification records. These values are owner-reported;
// only the retailer can complete and confirm actual verification.
(function(root){
 const STATES=Object.freeze(['not-started','waiting','owner-confirmed','not-required']);
 function state(value){return STATES.includes(value)?value:'not-started';}
 function phone(value){
  const input=String(value||'').trim();
  if(!input)return '';
  if(!/^[+\d ().-]+$/.test(input))throw Error('Enter a real phone number, with country code if outside the US.');
  const digits=input.replace(/\D/g,'');
  if(input.includes('+') && (!input.startsWith('+') || digits.length<8 || digits[0]==='0' || digits.length===10))throw Error('Include a valid international country code after +.');
  const normalized=!input.startsWith('+') && digits.length===10?'1'+digits:digits;
  if(!/^[1-9]\d{7,14}$/.test(normalized))throw Error('Enter a valid phone number (8–15 digits including country code).');
  return '+'+normalized;
 }
 function normalizedCredential(value){
  const obj=value&&typeof value==='object'?value:{};
  let savedPhone='';try{savedPhone=phone(obj.phone);}catch(_){/* never trust imported records */}
  return {
   password:typeof obj.password==='string'&&obj.password.length<=200?obj.password:'',
   updated:typeof obj.updated==='string'?obj.updated:'',
   consentAt:typeof obj.consentAt==='string'?obj.consentAt:'',
   phone:savedPhone,
   emailState:state(obj.emailState),
   smsState:state(obj.smsState)
  };
 }
 function canRecordComplete(credential){
  const c=normalizedCredential(credential);
  return ['owner-confirmed','not-required'].includes(c.emailState) &&
   ['owner-confirmed','not-required'].includes(c.smsState);
 }
 // Use only the supplied phone number. No replacement number is considered verified or reachable.
 // Exactly one of the seven local digits changes. The 3-digit area code (and optional +1)
 // and original punctuation remain unchanged. There are at most 7*9=63 variations per base.
 function phoneKey(value){
  const digits=String(value??'').replace(/\D/g,'');
  if(!digits&&!String(value??'').trim())return '';
  if(digits.length===10&&/^[+\d ().-]+$/.test(String(value)))return digits;
  if(digits.length===11&&digits[0]==='1'&&/^[+\d ().-]+$/.test(String(value)))return digits.slice(1);
  throw Error('Phone jig requires the customer\'s 10-digit US number (optional +1 prefix).');
 }
 function jigPhone(value,used=new Set()){
  const raw=String(value??'').trim();if(!raw)return '';
  const original=phoneKey(raw);const chars=[...raw];
  const digitSlots=chars.map((ch,i)=>/\d/.test(ch)?i:-1).filter(i=>i>=0);
  const offset=digitSlots.length===11?1:0;
  for(let candidate=0;candidate<63;candidate++){
   // Rotate positions from right to left; ensure each variant is one digit away.
   const index=9-Math.floor(candidate/9),change=(candidate%9)+1;
   const old=Number(original[index]);const next=String((old+change)%10);
   const digits=original.slice(0,index)+next+original.slice(index+1);
   if(used.has(digits))continue;
   const output=[...chars];output[digitSlots[offset+index]]=next;
   used.add(digits);return output.join('');
  }
  throw Error('More than 63 distinct one-digit variations are needed for the same supplied phone number. Divide this batch or provide another authorized number.');
 }
 const api=Object.freeze({STATES,state,phone,phoneKey,jigPhone,normalizedCredential,canRecordComplete});
 if(typeof module==='object'&&module?.exports)module.exports=api;
 else root.Verification=api;
})(typeof window!=='undefined'?window:globalThis);
