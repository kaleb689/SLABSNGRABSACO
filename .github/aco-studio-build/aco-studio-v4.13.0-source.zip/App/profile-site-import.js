/* Website-to-Profile-Studio handoff for authorized Admin customers.
   Customer data stays in current process memory and is cleared after sign-out.
   Payment details are only displayed as masked references; no PAN or CVV export. */
(()=>{'use strict';
 const source=()=>window.JigWebsiteCustomers;
 const local=()=>window.JigStudioLocalImport;
 const bridge=()=>window.desktopAPI?.site;
 const $=id=>document.getElementById(id);
 const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const str=value=>String(value??'').trim();
 const knownRetailers=new Set(['target','walmart','pokemoncenter']);
 let detail=null,loadTicket=0,lastImportName='';
 const validAddress=a=>Boolean(str(a?.address||a?.addressLine1)&&str(a?.city)&&str(a?.state)&&str(a?.zip||a?.zipCode));
 const addressLabel=a=>[str(a.address||a.addressLine1),str(a.address2||a.addressLine2),[a.city,a.state,a.zip||a.zipCode].filter(Boolean).join(' ')].filter(Boolean).join(', ');
 const title=x=>[x.firstName,x.lastName].filter(Boolean).join(' ');
 const safeClone=x=>JSON.parse(JSON.stringify(x));
 function notice(value,error=false){$('studioImportStatus').textContent=value;$('studioImportStatus').style.borderLeftColor=error?'#fd998c':'#60cfc0';}
 function option(value,label){const o=document.createElement('option');o.value=value;o.textContent=label;return o;}
 function showStatus(){
  const online=source()?.connected()===true;
  $('studioImportBadge').textContent=online?'Website live':'Admin sign-in required';
  $('studioImportBadge').classList.toggle('ready',online);
  $('studioLoadDetails').disabled=!online;
  $('studioSignIn').hidden=online;
 }
 function refreshCustomers(preferred=''){
  showStatus();
  const customers=source()?.list?.()||[];
  const select=$('studioCustomerPick'),prior=preferred||select.value;
  select.replaceChildren(option('','Choose a website customer'),...customers.map(c=>option(c.id,c.name+' | '+c.email+(c.tierCount?' | '+c.tierCount+' profiles':''))));
  if(customers.some(c=>c.id===prior))select.value=prior;
  const stillThere=customers.some(c=>c.id===prior);
  if(!stillThere){detail=null;$('studioImportDetails').hidden=true;lastImportName='';$('studioJigExport').disabled=true;}
  if(!customers.length){
   notice(source()?.connected()?'No website customers were returned. Try Sync now or check your Admin access.':'Use Sign in to website Admin to load your existing customer records.');
  }
 }
 function savedShipping(){
  if(!detail)return [];
  const fallbackPhone=str(detail.customer?.shipping?.phone||detail.customer?.billing?.phone);
  const addresses=Array.isArray(detail.saved?.addresses)?detail.saved.addresses.filter(validAddress).map(a=>({...a,phone:str(a.phone||fallbackPhone)})):[];
  if(addresses.length)return addresses;
  return validAddress(detail.customer?.shipping)?[{...detail.customer.shipping,id:'customer-profile-fallback',label:'Customer profile address'}]:[];
 }
 function savedBilling(){
  if(!detail)return [];
  // The website currently provides a shared saved-address collection; do not
  // invent another billing address when no distinct billing source exists.
  const shipping=savedShipping();const billing=detail.customer?.billing;
  if(validAddress(billing)&&!shipping.some(a=>addressLabel(a)===addressLabel(billing)))
   return [...shipping,{...billing,id:'customer-billing-fallback',label:'Saved billing address'}];
  return shipping;
 }
 const savedCards=()=>Array.isArray(detail?.saved?.paymentMethods)?detail.saved.paymentMethods:[];
 function renderChecks(target,name,items,labeler){
  $(target).innerHTML=items.length?items.map((item,index)=>
   '<label><input type="checkbox" name="'+name+'" value="'+index+'" checked><span>'+esc(labeler(item,index))+'</span></label>').join(''):
   '<small>No records found for this customer.</small>';
 }
 function updateBillState(){
  const disabled=$('studioBillingSame').checked;
  $('studioBillingChoices').classList.toggle('inactive',disabled);
  $('studioBillAll').disabled=disabled;
  for(const x of $('studioBillingChoices').querySelectorAll('input'))x.disabled=disabled;
 }
 function renderDetails(){
  const c=detail?.customer;if(!c)return;
  $('studioImportCount').max=String(Math.min(100,Math.max(1,Number(c.tierCount)||1)));
  $('studioImportCount').value=String(Math.min(5,Math.max(1,Number(c.tierCount)||1)));
  const ships=savedShipping(),bills=savedBilling(),cards=savedCards();
  renderChecks('studioShippingChoices','studioShip',ships,(a,i)=>(a.label||'Shipping '+(i+1))+' | '+addressLabel(a));
  renderChecks('studioBillingChoices','studioBill',bills,(a,i)=>(a.label||'Billing '+(i+1))+' | '+addressLabel(a));
  renderChecks('studioCardChoices','studioCard',cards,(card,i)=>{
   const expiry=[str(card.expMonth),str(card.expYear)].filter(Boolean).join('/');
   return [card.label||card.brand||'Card '+(i+1),str(card.cardholder),card.last4?'ending '+card.last4:'number hidden',expiry?'exp '+expiry:''].filter(Boolean).join(' | ');
  });
  for(const id of ['studioShipAll','studioBillAll','studioCardAll'])$(id).checked=true;
  $('studioBillingSame').checked=true;
  updateBillState();
  $('studioImportDetails').hidden=false;
  $('studioJigExport').disabled=true;
  lastImportName='';
  notice('Loaded '+c.name+' from your website: '+ships.length+' shipping address(es), '+cards.length+' masked card reference(s). Select sources, quantity and retailer, then load profiles into Profile Studio.');
 }
 async function loadCustomer(id){
  if(!id)return notice('Choose a website customer first.',true);
  const ticket=++loadTicket;
  detail=null;$('studioImportDetails').hidden=true;
  $('studioLoadDetails').disabled=true;
  notice('Retrieving the selected customer\'s saved information from the authorized website session...');
  try{
   const result=await source()?.detail?.(id);
   if(ticket!==loadTicket)return;
   if(!result||result.customer?.id!==id)throw Error('The website customer changed while loading.');
   detail=result;renderDetails();
   const addresses=savedShipping();
   try{await window.desktopAPI?.jigBanks?.aco?.sync?.(id);document.dispatchEvent(new CustomEvent('jigstudio:aco-addresses-synced',{detail:{customerId:id}}));}
   catch(e){notice('Customer loaded. Encrypted ACO address bank could not sync: '+e.message,true);}
  }catch(error){if(ticket===loadTicket)notice(error.message||'Unable to load customer information.',true);}
  finally{if(ticket===loadTicket)$('studioLoadDetails').disabled=source()?.connected()!==true;}
 }
 function selected(target,name,arr){
  return [...$(target).querySelectorAll('input[name="'+name+'"]:checked')]
   .map(x=>arr[Number(x.value)]).filter(Boolean).map(safeClone);
 }
 function requireCount(max){
  const count=Number($('studioImportCount').value);
  if(!Number.isSafeInteger(count)||count<1||count>Math.min(100,max))
   throw Error('Choose 1 to '+Math.min(100,max)+' profiles, within this customer\'s paid allowance.');
  return count;
 }
 async function importProfiles(){
  if(!detail||detail.customer?.id!==$('studioCustomerPick').value)throw Error('Load the selected customer information first.');
  if(!source()?.connected())throw Error('Website Admin session expired. Sign in again.');
  const retailer=$('studioRetailer').value;
  if(!knownRetailers.has(retailer))throw Error('Choose a supported retailer.');
  const count=requireCount(Number(detail.customer.tierCount)||0);
  const ships=selected('studioShippingChoices','studioShip',savedShipping());
  if(!ships.length)throw Error('Select at least one complete customer shipping address.');
  const billingSame=$('studioBillingSame').checked;
  const bills=billingSame?[]:selected('studioBillingChoices','studioBill',savedBilling());
  if(!billingSame&&!bills.length)throw Error('Select at least one billing address, or enable Same as shipping.');
  const chosenCards=selected('studioCardChoices','studioCard',savedCards());
  const accounts=(Array.isArray(detail.linked)?detail.linked:[]).filter(x=>x?.retailer===retailer&&x?.active===true);
  const profiles=Array.from({length:count},(_,i)=>{
   const ship=ships[i%ships.length],bill=billingSame?ship:bills[i%bills.length];
   const card=chosenCards.length?chosenCards[i%chosenCards.length]:null;
   return {shipping:ship,billing:bill,email:str(accounts[i]?.loginEmail),phone:str(ship.phone||bill.phone||detail.customer?.shipping?.phone||detail.customer?.billing?.phone),
     paymentRef:card?{id:str(card.id),last4:str(card.last4),brand:str(card.brand),cardholder:str(card.cardholder)}:null};
  });
  const template=await bridge()?.makeTemplate?.({retailer,customerName:detail.customer.name,profiles});
  if(!template?.name||!template.body)throw Error('The desktop could not build a valid retailer template.');
  const safeName=detail.customer.name.replace(/[^a-z0-9_-]+/gi,'_').slice(0,48)||'Customer';
  const fileName=safeName+'_'+template.name;
  const result=await local()?.importWebsiteTemplate(fileName,template.body,detail.customer.id);
  if(!result)throw Error('Profile Studio could not open the generated template.');
  lastImportName=result.name;
  $('studioJigExport').disabled=false;
  $('studioExportWithLocalCards').disabled=false;
  const missing=profiles.filter(x=>!x.email).length;
  const missingPhone=profiles.filter(x=>!x.phone).length;
  const payment=chosenCards.length?'Masked card selections are visible above; real PAN/CVV are never exported.':'No card references selected. Payment fields remain in the template but are empty.';
  notice('Loaded '+result.profiles+' '+(retailer==='target'?'Shikari CSV':'Valor JSON')+' profile(s) for '+detail.customer.name+' into the jig editor. '+payment+(missing?' '+missing+' profile(s) do not yet have a linked retailer login.':'')+(missingPhone?' '+missingPhone+' profile(s) do not have a saved phone number. Phone will remain empty until you add one to the customer profile.':''));
  document.dispatchEvent(new CustomEvent('jigstudio:profiles-imported'));
  $('ruleGroups')?.scrollIntoView({behavior:'smooth',block:'start'});
 }
 function selectorAll(toggle,target){
  $(toggle).addEventListener('change',e=>{
   for(const input of $(target).querySelectorAll('input[type=checkbox]:not(:disabled)'))input.checked=e.target.checked;
  });
  $(target).addEventListener('change',()=>{
   const checkboxes=[...$(target).querySelectorAll('input[type=checkbox]:not(:disabled)')];
   $(toggle).checked=checkboxes.length>0&&checkboxes.every(x=>x.checked);
  });
 }
 function resetPrivate(){detail=null;lastImportName='';++loadTicket;$('studioImportDetails').hidden=true;$('studioJigExport').disabled=true;if($('studioExportWithLocalCards'))$('studioExportWithLocalCards').disabled=true;refreshCustomers();}
 function bind(){
  const exportLocalButton=document.createElement('button');exportLocalButton.type='button';exportLocalButton.id='studioExportWithLocalCards';exportLocalButton.className='btn primary slim';exportLocalButton.textContent='Export with locally saved cards';exportLocalButton.disabled=true;
  $('studioJigExport')?.after(exportLocalButton);
  exportLocalButton.addEventListener('click',async()=>{
   if(!detail||!lastImportName||!local()?.isCurrentWebsiteImport?.(lastImportName))return notice('Load the selected website customer into Profile Studio first.',true);
   if(!confirm('Export these profiles with card numbers from your locally saved customer cards? The resulting Shikari/Valor file is UNENCRYPTED and will contain the full numbers. Custom project codes are not exported as CVVs.'))return;
   exportLocalButton.disabled=true;
   try{
    const current=local().currentProcessed();
    const result=await window.desktopAPI.localCards.exportProfiles({customerId:detail.customer.id,records:current.records,fileName:current.fileName,confirmUnencryptedExport:true});
    notice(result.saved?'Saved '+result.name+' with '+result.localCardProfiles+' local card assignment(s). No website records were changed.':'Export cancelled.');
   }catch(error){notice(error.message||'Could not export local saved cards.',true);}
   finally{exportLocalButton.disabled=false;}
  });
  const cardButton=document.createElement('button');cardButton.type='button';cardButton.id='studioManageLocalCards';cardButton.className='btn secondary slim';cardButton.textContent='◈ Manage local customer cards';$('studioCustomerPick')?.closest('.studioWebsiteImport')?.append(cardButton);
  $('studioSignIn').addEventListener('click',()=>{
   if(!source()?.signIn)return notice('The website connection is unavailable in this build.',true);
   source().signIn();notice('Sign in once in the separate Admin window. The customer list will load automatically.');
  });
  $('studioReloadCustomers').addEventListener('click',async()=>{
   if(!source()?.connected())return notice('Sign in to website Admin first.',true);
   notice('Refreshing website customers...');try{await source().refresh();refreshCustomers();}catch(err){notice(err.message,true);}
  });
  $('studioLoadDetails').addEventListener('click',()=>void loadCustomer($('studioCustomerPick').value));
  $('studioCustomerPick').addEventListener('change',()=>{detail=null;lastImportName='';$('studioImportDetails').hidden=true;$('studioJigExport').disabled=true;if($('studioExportWithLocalCards'))$('studioExportWithLocalCards').disabled=true;});
  $('studioBillingSame').addEventListener('change',updateBillState);
  for(const [button,target] of [['studioShipAll','studioShippingChoices'],['studioBillAll','studioBillingChoices'],['studioCardAll','studioCardChoices']])selectorAll(button,target);
  $('studioImportProfiles').addEventListener('click',async()=>{
   const button=$('studioImportProfiles');button.disabled=true;
   notice('Preparing Shikari / Valor profiles from the selected live website information...');
   try{await importProfiles();}catch(err){notice(err.message,true);}finally{button.disabled=false;}
  });
  $('studioJigExport').addEventListener('click',()=>{
   if(!lastImportName||!local()?.isCurrentWebsiteImport?.(lastImportName)){
    notice('Choose the newly imported customer file above before exporting.',true);return;
   }
   local().exportCurrent();
  });
  document.addEventListener('jigstudio:customers-updated',e=>{
   if(e.detail?.connected)refreshCustomers();else resetPrivate();
  });
  refreshCustomers();
 }
 window.JigStudioProfileImport=Object.freeze({
  openCustomer(id){
   document.querySelector('.tabButton[data-tab="jig"]')?.click();
   document.dispatchEvent(new CustomEvent('jigstudio:open-import'));
   refreshCustomers(id);
   if(source()?.connected()&&$('studioCustomerPick').value===id)void loadCustomer(id);
   else if(!source()?.connected())notice('Sign in once to load this website customer into Profile Studio.',true);
   $('studioWebsiteImport').scrollIntoView({behavior:'smooth',block:'start'});
  }
 });
 bind();
})();
