'use strict';
// Isolated Windows update helper. Runs using the installed Electron runtime in
// ELECTRON_RUN_AS_NODE mode. No PowerShell policy or system-wide Node is needed.
// This helper handles application code only, never Electron userData or secrets.
const fs = require('node:fs');
const fsp = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const zlib = require('node:zlib');
const { spawn } = require('node:child_process');
const crypto = require('node:crypto');
const LIMIT_ZIP = 25 * 1024 * 1024;
const LIMIT_UNPACK = 30 * 1024 * 1024;
const LIMIT_ENTRIES = 500;
const ID = 'com.slabsngrabsaco.jigstudio.owner';
const NAME = 'slabsngrabsaco-jig-studio';
const CRC_TABLE = Array.from({length:256}, (_,i)=>{
 let x=i; for(let j=0;j<8;j++) x=(x&1) ? ((x>>>1)^0xedb88320) : (x>>>1); return x>>>0;
});
function crc32(data){
 let value=0xffffffff;
 for(const byte of data) value=(value>>>8)^CRC_TABLE[(value^byte)&255];
 return (value^0xffffffff)>>>0;
}
function compareVersion(a,b){
 const parse=x=>/^\d+\.\d+\.\d+$/.test(String(x)) ? String(x).split('.').map(Number) : null;
 const aa=parse(a), bb=parse(b);
 if(!aa||!bb) throw Error('Update version is invalid.');
 for(let i=0;i<3;i++)if(aa[i]!==bb[i])return aa[i]>bb[i]?1:-1;
 return 0;
}
function validateZipName(name){
 if(typeof name!=='string'||!name||name.length>300||name.includes('\\')||name.includes('\0')||name.startsWith('/')||name.includes(':')||name.split('/').some(part=>part==='..'||part==='.')||/^[A-Za-z]:/.test(name))
  throw Error('Update archive contains an unsafe file path.');
 return true;
}
function unzipAppEntries(archive){
 if(!Buffer.isBuffer(archive)||archive.length>LIMIT_ZIP||archive.length<22)throw Error('Update ZIP is invalid or exceeds the size limit.');
 let eocd=-1;
 for(let i=archive.length-22;i>=Math.max(0,archive.length-65557);i--){
  if(archive.readUInt32LE(i)===0x06054b50 && i+22+archive.readUInt16LE(i+20)===archive.length){eocd=i;break;}
 }
 if(eocd<0)throw Error('Update ZIP has no valid central directory.');
 const number=archive.readUInt16LE(eocd+10), offset=archive.readUInt32LE(eocd+16), size=archive.readUInt32LE(eocd+12);
 if(number<1||number>LIMIT_ENTRIES||archive.readUInt16LE(eocd+8)!==number || offset+size>eocd)
  throw Error('Update ZIP entry list is invalid.');
 const entries=new Map();let cursor=offset,expanded=0;
 for(let i=0;i<number;i++){
  if(cursor+46>archive.length||archive.readUInt32LE(cursor)!==0x02014b50)throw Error('Update ZIP contains an invalid file record.');
  const flags=archive.readUInt16LE(cursor+8), method=archive.readUInt16LE(cursor+10), crc=archive.readUInt32LE(cursor+16);
  const compressed=archive.readUInt32LE(cursor+20), length=archive.readUInt32LE(cursor+24);
  const nameLength=archive.readUInt16LE(cursor+28), extraLength=archive.readUInt16LE(cursor+30), commentLength=archive.readUInt16LE(cursor+32);
  const localOffset=archive.readUInt32LE(cursor+42), attributes=archive.readUInt32LE(cursor+38);
  if(cursor+46+nameLength+extraLength+commentLength>archive.length || length>LIMIT_UNPACK || expanded+length>LIMIT_UNPACK)
   throw Error('Update ZIP expands beyond the safe size limit.');
  if(flags&1||!([0,8].includes(method))||flags&0x8)throw Error('Update ZIP uses an unsupported compression method.');
  const unixMode=(attributes>>>16)&0xf000;
  if(unixMode===0xa000)throw Error('Update ZIP contains a symbolic link.');
  const name=archive.subarray(cursor+46,cursor+46+nameLength).toString('utf8');
  validateZipName(name);
  if(entries.has(name))throw Error('Update ZIP contains duplicate files.');
  if(localOffset+30>offset||archive.readUInt32LE(localOffset)!==0x04034b50)throw Error('Update ZIP has an invalid local file header.');
  const localNameLength=archive.readUInt16LE(localOffset+26), localExtraLength=archive.readUInt16LE(localOffset+28);
  const localName=archive.subarray(localOffset+30,localOffset+30+localNameLength).toString('utf8');
  if(localName!==name||archive.readUInt16LE(localOffset+8)!==method)throw Error('Update ZIP file headers disagree.');
  const start=localOffset+30+localNameLength+localExtraLength;
  if(start+compressed>offset)throw Error('Update ZIP entry exceeds file data bounds.');
  if(!name.endsWith('/')){
   const payload=archive.subarray(start,start+compressed);
   let data;
   try{data=method===8 ? zlib.inflateRawSync(payload,{maxOutputLength:Math.min(LIMIT_UNPACK,length+1)}) : payload;}
   catch {throw Error('Update ZIP contains invalid compressed data.');}
   if(data.length!==length||crc32(data)!==crc)throw Error('Update ZIP file integrity check failed.');
   entries.set(name,data);expanded+=data.length;
  }
  cursor+=46+nameLength+extraLength+commentLength;
 }
 if(cursor!==offset+size)throw Error('Update ZIP directory length is invalid.');
 const roots=new Set();
 for(const key of entries.keys()){
  if(key==='App/package.json')roots.add('App/');
  else if(key.endsWith('/App/package.json'))roots.add(key.slice(0,-'package.json'.length));
 }
 if(roots.size!==1)throw Error('Update ZIP must contain exactly one Jig Studio application.');
 const prefix=[...roots][0];
 const files=new Map();
 for(const [key,data] of entries){
  if(!key.startsWith(prefix))continue;
  const rel=key.slice(prefix.length);
  if(!rel)continue;
  validateZipName(rel);
  files.set(rel,data);
 }
 return files;
}
function fileNameAllowed(name){return typeof name==='string' && /^[A-Za-z0-9][A-Za-z0-9_.\/-]{0,149}$/.test(name) && !name.includes('..') && !name.includes('\\') && !name.startsWith('/');}
function validateNewPackage(files,currentVersion,targetVersion){
 const bytes=files.get('package.json');
 if(!bytes)throw Error('Update ZIP is missing package.json.');
 let pkg;
 try{pkg=JSON.parse(bytes.toString('utf8'));}
 catch{throw Error('Update ZIP contains invalid package.json.');}
 if(pkg.name!==NAME||pkg.build?.appId!==ID||compareVersion(pkg.version,currentVersion)<=0)
  throw Error('Update package is not a newer version of Jig Studio.');
 if(targetVersion&&targetVersion!==pkg.version)throw Error('Downloaded update does not match the verified release.');
 const inventory=pkg.build?.files;
 if(!Array.isArray(inventory)||inventory.length<15||inventory.length>120||new Set(inventory).size!==inventory.length||!inventory.every(fileNameAllowed))
  throw Error('Update package contains an invalid file inventory.');
 for(const file of inventory)if(!files.has(file))throw Error('Update package is missing application file: '+file);
 for(const file of ['main.js','preload.js','desktop-updates.js','windows-update.js','package.json','index.html'])
  if(!inventory.includes(file))throw Error('Update package is missing a required application component.');
 return {pkg,inventory};
}
async function prepareStaging({zipPath,installRoot,currentVersion,targetVersion,log}){
 const resources=path.join(installRoot,'resources');
 const appPath=path.join(resources,'app');
 const exe=path.join(installRoot,'JigStudio.exe');
 const currentPkg=JSON.parse(await fsp.readFile(path.join(appPath,'package.json'),'utf8'));
 if(currentPkg.name!==NAME||currentPkg.build?.appId!==ID||currentPkg.version!==currentVersion)throw Error('Installed app identity or version does not match the update request.');
 if(!fs.existsSync(exe))throw Error('The installed JigStudio.exe is missing.');
 const buffer=await fsp.readFile(zipPath);
 const files=unzipAppEntries(buffer);
 const {pkg,inventory}=validateNewPackage(files,currentVersion,targetVersion);
 const a={...currentPkg.build},b={...pkg.build};delete a.files;delete b.files;
 if(JSON.stringify(a)!==JSON.stringify(b))throw Error('This update changes the installer configuration; use an official full installer.');
 const stage=path.join(resources,'app-staging-'+crypto.randomUUID());
 await fsp.mkdir(stage,{recursive:true});
 try{
  for(const name of inventory){
   const dest=path.join(stage,...name.split('/'));
   await fsp.mkdir(path.dirname(dest),{recursive:true});
   await fsp.writeFile(dest,files.get(name));
  }
  if((await fsp.stat(path.join(stage,'main.js'))).size<100)throw Error('Staged application files are incomplete.');
  if(log)log('Validated and staged v'+pkg.version+' ('+inventory.length+' application files).');
  return {stage,appPath,exe,version:pkg.version};
 }catch(error){await fsp.rm(stage,{recursive:true,force:true});throw error;}
}
async function writeStatus(file,phase,message,currentVersion,targetVersion){
 await fsp.mkdir(path.dirname(file),{recursive:true});
 const temp=file+'.tmp-'+crypto.randomUUID();
 await fsp.writeFile(temp,JSON.stringify({phase,message,currentVersion,targetVersion,updatedAt:new Date().toISOString()}),'utf8');
 await fsp.rename(temp,file);
}
function isProcessRunning(pid){
 try{process.kill(pid,0);return true;}
 catch(error){return error.code==='EPERM';}
}
async function waitForParent(pid,timeoutMs=120000){
 const until=Date.now()+timeoutMs;
 while(Date.now()<until){if(!isProcessRunning(pid))return;await new Promise(r=>setTimeout(r,250));}
 throw Error('Jig Studio did not close within two minutes. The old installation was preserved.');
}
async function commitStagedUpdate({stage,appPath,exe,version}, {log,skipRelaunch=false}={}){
 const backup=path.join(path.dirname(appPath),'app-backup-'+crypto.randomUUID());
 let oldRenamed=false,installed=false;
 try{
  await fsp.rename(appPath,backup);oldRenamed=true;
  await fsp.rename(stage,appPath);installed=true;
  const pkg=JSON.parse(await fsp.readFile(path.join(appPath,'package.json'),'utf8'));
  if(pkg.version!==version)throw Error('Installed version does not match staged update.');
  if(!skipRelaunch){
   const env={...process.env};delete env.ELECTRON_RUN_AS_NODE;
   const child=spawn(exe,[],{detached:true,cwd:path.dirname(exe),stdio:'ignore',windowsHide:true,env});
   await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});
   child.unref();
  }
  if(log)log('Updated application files to v'+version+' and started Jig Studio. Backup code retained at '+backup+'.');
 }catch(error){
  if(installed)await fsp.rm(appPath,{recursive:true,force:true}).catch(()=>{});
  if(oldRenamed)await fsp.rename(backup,appPath).catch(()=>{});
  throw error;
 }
}
async function runHelper(settings,{skipWait=false,skipRelaunch=false}={}){
 const {zipPath,installRoot,currentVersion,targetVersion,appProcessId,readyFile,statusFile,logFile}=settings;
 const log=message=>{
  try{fs.mkdirSync(path.dirname(logFile),{recursive:true});fs.appendFileSync(logFile,'['+new Date().toISOString()+'] '+String(message)+'\n');}
  catch{ /* Best-effort diagnostic logging. */ }
 };
 let staged=null;
 log('Node update helper launched (pid '+process.pid+').');
 try{
  await writeStatus(statusFile,'validating','Validating Jig Studio update.',currentVersion,targetVersion);
  staged=await prepareStaging({zipPath,installRoot,currentVersion,targetVersion,log});
  await writeStatus(statusFile,'ready','Update files staged and verified. Waiting for app to close.',currentVersion,staged.version);
  await fsp.writeFile(readyFile,'ready','utf8');
  if(!skipWait)await waitForParent(appProcessId);
  await writeStatus(statusFile,'installing','Applying verified files.',currentVersion,staged.version);
  await commitStagedUpdate(staged,{log,skipRelaunch});
  await writeStatus(statusFile,'installed','Installed Jig Studio v'+staged.version+'.',currentVersion,staged.version);
  log('Update completed successfully.');
  return {installed:true,version:staged.version};
 }catch(error){
  log('FAILED: '+error.message);
  await writeStatus(statusFile,'failed',error.message,currentVersion,targetVersion).catch(()=>{});
  if(staged?.stage)await fsp.rm(staged.stage,{recursive:true,force:true}).catch(()=>{});
  throw error;
 }finally{
  await fsp.rm(readyFile,{force:true}).catch(()=>{});
  if(zipPath.startsWith(path.join(os.tmpdir(),'jigstudio-owner-update-'))&&zipPath.endsWith('.zip'))
   await fsp.rm(zipPath,{force:true}).catch(()=>{});
 }
}
async function main(){
 if(process.argv.length<3)throw Error('Updater was launched without arguments.');
 let options;
 try{options=JSON.parse(process.argv[2]);}
 catch{throw Error('Updater arguments were invalid.');}
 for(const field of ['zipPath','installRoot','currentVersion','targetVersion','readyFile','statusFile','logFile'])
  if(typeof options[field]!=='string'||!options[field])throw Error('Missing updater setting: '+field);
 if(!Number.isSafeInteger(options.appProcessId)||options.appProcessId<=0)throw Error('Invalid app process identifier.');
 try{await runHelper(options);process.exitCode=0;}
 catch(error){console.error('Jig Studio update helper failed: '+error.message);process.exitCode=1;}
}
if(require.main===module)main().catch(err=>{console.error('Jig Studio update helper failed to start: '+err.message);process.exitCode=1;});
module.exports={unzipAppEntries,validateNewPackage,prepareStaging,commitStagedUpdate,runHelper,compareVersion};
