# SLABSNGRABSACO Jig Studio verified Windows updater.
# Executed from a temporary copy, never from the app directory being replaced.
# Customer/userData folders and encrypted credentials are never read or modified.
param(
 [Parameter(Mandatory=$true)][string]$ZipPath,
 [Parameter(Mandatory=$true)][string]$InstallRoot,
 [Parameter(Mandatory=$true)][string]$CurrentVersion,
 [Parameter(Mandatory=$true)][int]$AppProcessId,
 [Parameter(Mandatory=$true)][string]$ReadyFile,
 [Parameter(Mandatory=$true)][string]$StatusFile,
 [string]$TargetVersion=''
)
$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$log=Join-Path $env:LOCALAPPDATA 'JigStudio-update.log'
$extract=Join-Path $env:TEMP ('JigStudio-update-unzip-'+[guid]::NewGuid().ToString('N'))
$resourceDir=Join-Path $InstallRoot 'resources'
$appPath=Join-Path $resourceDir 'app'
$stage=Join-Path $resourceDir ('app-staging-'+[guid]::NewGuid().ToString('N'))
$backup=Join-Path $resourceDir ('app-backup-'+[guid]::NewGuid().ToString('N'))
$exe=Join-Path $InstallRoot 'JigStudio.exe'
$swapBegan=$false
$target=$TargetVersion

function Log([string]$message) {
 ('['+(Get-Date).ToString('s')+'] '+$message) | Out-File -FilePath $log -Append -Encoding UTF8
}
function Write-State([string]$phase,[string]$message) {
 try {
  $state=@{phase=$phase;message=$message;currentVersion=$CurrentVersion;targetVersion=$target;updatedAt=(Get-Date).ToString('o')}
  $body=$state | ConvertTo-Json -Compress
  [IO.File]::WriteAllText($StatusFile,$body,[Text.Encoding]::UTF8)
 }catch{Log ('Unable to write updater status: '+$_.Exception.Message)}
}
function Validate-Update([string]$folder) {
 $required=@('index.html','main.js','preload.js','desktop-updates.js','windows-update.ps1','package.json')
 foreach($file in $required){if(-not (Test-Path -LiteralPath (Join-Path $folder $file) -PathType Leaf)){return $false}}
 $pkg=Get-Content (Join-Path $folder 'package.json') -Raw | ConvertFrom-Json
 if($pkg.name -ne 'slabsngrabsaco-jig-studio' -or $pkg.build.appId -ne 'com.slabsngrabsaco.jigstudio.owner'){return $false}
 if(-not ($pkg.version -match '^\d+\.\d+\.\d+$')){return $false}
 if([Version]$pkg.version -le [Version]$CurrentVersion){throw ('Update version '+$pkg.version+' is not newer than installed '+$CurrentVersion+'.')}
 if($target -and $pkg.version -ne $target){throw 'Update ZIP version does not match the verified release.'}
 $script:target=$pkg.version
 return $true
}
try {
 Log ('Updater started. Installed='+$CurrentVersion+', requested='+$TargetVersion)
 Write-State 'validating' 'Verifying update ZIP before closing Jig Studio.'
 if(-not (Test-Path -LiteralPath $ZipPath -PathType Leaf)){throw 'Update ZIP file not found.'}
 if(-not (Test-Path -LiteralPath $exe -PathType Leaf)){throw 'The installed JigStudio.exe is missing.'}
 if(-not (Test-Path -LiteralPath $appPath -PathType Container)){throw 'The installed app folder is missing.'}
 New-Item -ItemType Directory -Force -Path $extract | Out-Null
 Add-Type -AssemblyName System.IO.Compression.FileSystem
 $arc=[IO.Compression.ZipFile]::OpenRead($ZipPath)
 try {
  $size=0
  foreach($entry in $arc.Entries){
   $size+=$entry.Length
   if($size -gt 25000000){throw 'The update is larger than the source-only release limit.'}
   $relative=$entry.FullName.Replace('\','/')
   if($relative.StartsWith('/') -or $relative.Contains(':') -or ($relative.Split('/') -contains '..')){throw 'Update contains an invalid path.'}
   if((($entry.ExternalAttributes -shr 16) -band 61440) -eq 40960){throw 'Update contains a symbolic link.'}
  }
 }finally{$arc.Dispose()}
 [IO.Compression.ZipFile]::ExtractToDirectory($ZipPath,$extract)
 $sources=@(Get-ChildItem -LiteralPath $extract -Recurse -File -Filter 'package.json' | ForEach-Object { $_.Directory.FullName } | Select-Object -Unique)
 $src=$null
 foreach($candidate in $sources){if(Validate-Update $candidate){if($src){throw 'Update contains more than one application.'};$src=$candidate}}
 if(-not $src){throw 'The ZIP is not a valid, newer Jig Studio owner update.'}
 Copy-Item -LiteralPath $src -Destination $stage -Recurse -Force
 if(-not (Test-Path -LiteralPath (Join-Path $stage 'main.js') -PathType Leaf)){throw 'Staged update files are incomplete.'}
 Log ('Validated and staged version '+$target+'; waiting for old app to close.')
 Write-State 'ready' ('Validated v'+$target+'. Waiting for the app to close.')
 [IO.File]::WriteAllText($ReadyFile,'ready',[Text.Encoding]::ASCII)
 try { Wait-Process -Id $AppProcessId -Timeout 120 -ErrorAction Stop }
 catch { if(Get-Process -Id $AppProcessId -ErrorAction SilentlyContinue){throw 'Old Jig Studio process did not exit in time.'} }
 # A Windows update cannot replace files still held open by the old process.
 Write-State 'installing' ('Applying Jig Studio v'+$target+'.')
 if(Test-Path -LiteralPath $appPath){Move-Item -LiteralPath $appPath -Destination $backup -ErrorAction Stop;$swapBegan=$true}
 try { Move-Item -LiteralPath $stage -Destination $appPath -ErrorAction Stop }
 catch {
  if((Test-Path -LiteralPath $backup) -and -not (Test-Path -LiteralPath $appPath)) {Move-Item -LiteralPath $backup -Destination $appPath -ErrorAction SilentlyContinue}
  throw
 }
 $installed=(Get-Content -LiteralPath (Join-Path $appPath 'package.json') -Raw | ConvertFrom-Json).version
 if($installed -ne $target){throw ('Installed version is '+$installed+', expected '+$target+'.')}
 $uninstallKey='HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\SLABSNGRABSACO-JigStudio'
 if(Test-Path $uninstallKey){Set-ItemProperty -Path $uninstallKey -Name 'DisplayVersion' -Value $target -ErrorAction SilentlyContinue}
 Write-State 'installed' ('Installed Jig Studio v'+$target+'.')
 Log ('Installed v'+$target+' successfully; relaunching app.')
 Start-Process -FilePath $exe -WorkingDirectory $InstallRoot
 if(Test-Path -LiteralPath $backup){Remove-Item -LiteralPath $backup -Recurse -Force -ErrorAction SilentlyContinue}
}catch{
 $reason=$_.Exception.Message
 Log ('FAILED: '+$reason)
 Write-State 'failed' $reason
 # Restore the last working app if replacement failed after the original was moved.
 if($swapBegan -and (Test-Path -LiteralPath $backup)){
  if(Test-Path -LiteralPath $appPath){Remove-Item -LiteralPath $appPath -Recurse -Force -ErrorAction SilentlyContinue}
  if(-not (Test-Path -LiteralPath $appPath)){Move-Item -LiteralPath $backup -Destination $appPath -ErrorAction SilentlyContinue}
 }
 # Do not strand the user with a closed app after a failed update.
 if((Test-Path -LiteralPath $exe) -and -not (Get-Process -Name 'JigStudio' -ErrorAction SilentlyContinue)){
  try {Start-Process -FilePath $exe -WorkingDirectory $InstallRoot}catch{Log ('Could not reopen Jig Studio: '+$_.Exception.Message)}
 }
}finally{
 if(Test-Path -LiteralPath $extract){Remove-Item -LiteralPath $extract -Recurse -Force -ErrorAction SilentlyContinue}
 if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue}
 if($ZipPath -like (Join-Path $env:TEMP 'jigstudio-owner-update-*.zip')){Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue}
}
