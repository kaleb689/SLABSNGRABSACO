'use strict';
// Pure, testable adaptation of authenticated SLABSNGRABSACO Admin responses.
// Never transfer website PAN, CVV, encrypted secrets or retailer passwords to the desktop renderer.
const RETAILERS=Object.freeze({target:'Target',walmart:'Walmart',pokemoncenter:'Pokemon Center'});
const {randomUUID}=require('node:crypto');
const cardAllocation=require('./payment-allocation');
const clean=x=>String(x??'').trim();
const list=x=>Array.isArray(x)?x:Array.isArray(x?.submissions)?x.submissions:Array.isArray(x?.records)?x.records:[];
// Address records and customer/contact records may use different phone keys.
// Accept only the number explicitly stored for this customer; never fabricate one.
function phoneOf(v){
 if(!v||typeof v!=='object')return '';
 const fields=['phone','phoneNumber','phone_num','phone_number','mobile','mobilePhone','telephone','contactPhone'];
 for(const obj of [v,v.contact]){
  if(!obj||typeof obj!=='object')continue;
  for(const field of fields){const value=clean(obj[field]);if(value)return value;}
 }
 return '';
}
function customerId(v){return clean(v?.customerAccountId||v?.accountId||v?.id);}
function displayName(v){const p=v?.profile||v||{};return clean([p.firstName,p.lastName].filter(Boolean).join(' ')||p.profileName||v?.customerName||v?.name||v?.email||'Unnamed member');}
function tierCount(v){
 if(v?.accountOnly===true)return 0;
 const p=v?.plan||v?.membership||{};
 const qty=Number(p.profiles??p.profileCount??p.accounts??v?.paidProfileCount??v?.profileAllowance??v?.tierProfileCount);
 if(Number.isSafeInteger(qty)&&qty>0&&qty<=1000)return qty;
 const match=/(^|\D)(100|50|20|10|5|3|2|1)(?!\d)/.exec(clean(p.name||v?.planName||v?.membershipName));
 return match?Number(match[2]):0;
}
const postal=(v={})=>({firstName:clean(v.firstName),lastName:clean(v.lastName),phone:phoneOf(v),address:clean(v.address||v.addressLine1),address2:clean(v.address2||v.addressLine2),city:clean(v.city),state:clean(v.state),zip:clean(v.zip||v.zipCode),country:clean(v.country||v.countryCode||'US')});
function roster(paid,registered,activation){
 const result=new Map();
 function add(record,paidFlag){
  const id=customerId(record),email=clean(record?.profile?.email||record?.email||record?.customerEmail).toLowerCase();
  const key=id||email;if(!key)return;
  const current=result.get(key);
  const profile=postal(record?.profile||record);
  if(!profile.phone)profile.phone=phoneOf(record)||current?.shipping?.phone||'';
  const count=tierCount(record);
  if(!current||paidFlag&&!current.paid){
   result.set(key,{id:id||current?.id||'',orderId:paidFlag?clean(record.id):current?.orderId||'',name:displayName(record),email,
    tierCount:Math.max(count,current?.tierCount||0),paid:Boolean(paidFlag||current?.paid),shipping:profile,
    billing:{...profile},linkedCounts:{target:0,walmart:0,pokemoncenter:0},activationSlots:0});
  }else if(current){current.tierCount=Math.max(current.tierCount,count);}
 }
 for(const c of list(registered))add(c,false);
 for(const c of list(paid))add(c,true);
 for(const group of Array.isArray(activation?.customers)?activation.customers:[]){
  const id=clean(group.customerAccountId||group.accountId||group.id),email=clean(group.email||group.customerEmail).toLowerCase();
  const item=[...result.values()].find(c=>(id&&c.id===id)||(email&&c.email===email));
  if(item){item.activationSlots=(Array.isArray(group.profiles)?group.profiles:[]).filter(p=>p?.type==='paid').length;}
 }
 return [...result.values()].sort((a,b)=>a.name.localeCompare(b.name));
}
function safePaymentMethod(v){
 // Website Admin currently supplies a maskedNumber string. Derive ONLY last four
 // in the Node process; do not include full PAN, CVV or passwords in IPC results.
 const last4=clean(v?.last4||v?.lastFour).replace(/\D/g,'').slice(-4) ||
   clean(v?.maskedNumber).replace(/\D/g,'').slice(-4) ||
   clean(v?.acoCardNumber||v?.cardNumber).replace(/\D/g,'').slice(-4);
 return {id:clean(v?.id),label:clean(v?.cardLabel||v?.label),brand:clean(v?.brand||v?.type),
   cardholder:clean(v?.cardholder),last4,expMonth:clean(v?.expMonth),expYear:clean(v?.expYear)};
}
function savedDetails(payload){const fallbackPhone=phoneOf(payload)||phoneOf(payload?.profile)||phoneOf(payload?.customer);return {addresses:(Array.isArray(payload?.addresses)?payload.addresses:[]).map(v=>({...postal(v),phone:phoneOf(v)||fallbackPhone,id:clean(v.id),label:clean(v.label)})),paymentMethods:(Array.isArray(payload?.paymentMethods)?payload.paymentMethods:[]).map(safePaymentMethod)};}
function linked(payload){return (Array.isArray(payload?.memberships)?payload.memberships:[]).map(v=>({
  id:clean(v.id),assignmentId:clean(v.assignmentId),type:clean(v.type),profileName:clean(v.profileName),
  retailer:retailerFor(v),loginEmail:clean(v?.retailers?.[retailerFor(v)]?.username||v?.accountEmail),
  customerProfile:postal(v?.customerProfile||{}),exportReady:v.exportReady===true,
  active:v.active===true,activationStatus:clean(v.activationStatus),jigNeeded:v.jigNeeded===true,
  updatedAt:clean(v.updatedAt)
 }));}
function retailerFor(v){const r=v?.retailers||{};if(typeof v?.assignmentRetailer==='string'&&RETAILERS[v.assignmentRetailer])return v.assignmentRetailer;
 for(const key of Object.keys(r))if(['target','walmart','pokemoncenter','pkc'].includes(key))return key==='pkc'?'pokemoncenter':key;
 return 'target';}
function poolSearch(payload){return {total:Number(payload?.total||0),page:Number(payload?.page||1),pageCount:Number(payload?.pageCount||1),profiles:(Array.isArray(payload?.profiles)?payload.profiles:[]).map(v=>({
  id:clean(v.id),retailer:clean(v.retailer),loginEmail:clean(v.loginEmail),profileName:clean(v.profileName),status:clean(v.status),
  assignmentType:clean(v.assignmentType),assignmentId:clean(v.assignmentId),assignedTo:v?.assignedTo?{id:clean(v.assignedTo.id),name:clean(v.assignedTo.name)}:null
 }))};}
function slotRows(customer,linkedRecords,retailer){
 if(!RETAILERS[retailer])throw Error('Unsupported retailer');
 const related=(Array.isArray(linkedRecords)?linkedRecords:[]).filter(v=>v.retailer===retailer&&v.active);
 const total=Math.max(Number(customer?.tierCount)||0,related.length);
 return Array.from({length:total},(_,i)=>({slot:i+1,retailer,assignment:related[i]||null,status:related[i]?'linked':'blank'}));
}
function testOnlyPaymentFields(card){
 // Never accept website vault card objects: only session-entered test cards explicitly marked synthetic.
 if(!card||card.synthetic!==true)return {cardholder:'',number:'',expiration:'',cvv:'',type:'',month:'',year:''};
 const c=cardAllocation.normalize(card);
 return {cardholder:c.cardholder,number:c.number,expiration:c.month+'/'+c.year.slice(-2),cvv:c.cvv,type:c.type,month:c.month,year:c.year};
}
// Values are *explicitly synthetic* fixture data. This function never accepts customer vault records.
function exportTemplates(retailer,customerName,profiles,syntheticCard=null,privateOptions={}){
 const person=clean(customerName)||'Customer';
 const source=(Array.isArray(profiles)?profiles:[]).map((p,index)=>({
  name:person+' '+(index+1),email:clean(p.email),phone:phoneOf(p)||phoneOf(p.shipping)||phoneOf(p.billing),shipping:postal(p.shipping||{}),billing:postal(p.billing||p.shipping||{}),
  // Only explicit in-app synthetic card entries. No website card vault objects are read.
  card:privateOptions.localOwnerCards?.[index]||testOnlyPaymentFields(p.syntheticCard||syntheticCard)
 }));
 if(retailer==='target'){
  const columns=['profile_name','first_name','last_name','email','phone_num','cc_number','cc_exp_month','cc_exp_year','cc_cvv',
   'shipping_street','shipping_street_2','shipping_city','shipping_state','shipping_zip_code','shipping_country',
   'billing_first_name','billing_last_name','billing_street','billing_street_2','billing_city','billing_state','billing_zip_code','billing_country'];
  const quote=v=>'"'+clean(v).replace(/"/g,'""').replace(/^[=+@-]/,"'$&")+'"';
  const lines=source.map(p=>[p.name,p.shipping.firstName,p.shipping.lastName,p.email,p.phone.replace(/\D/g,''),p.card.number,p.card.month,p.card.year,p.card.cvv,p.shipping.address,p.shipping.address2,p.shipping.city,p.shipping.state,p.shipping.zip,p.shipping.country,
   p.billing.firstName,p.billing.lastName,p.billing.address,p.billing.address2,p.billing.city,p.billing.state,p.billing.zip,p.billing.country].map(quote).join(','));
  return {name:'Shikari_Target.csv',body:[columns.join(','),...lines].join('\r\n')+'\r\n',mime:'text/csv'};
 }
 if(!['walmart','pokemoncenter'].includes(retailer))throw Error('Unsupported retailer');
 const STATES={AL:'Alabama',AK:'Alaska',AZ:'Arizona',AR:'Arkansas',CA:'California',CO:'Colorado',CT:'Connecticut',DE:'Delaware',FL:'Florida',GA:'Georgia',HI:'Hawaii',ID:'Idaho',IL:'Illinois',IN:'Indiana',IA:'Iowa',KS:'Kansas',KY:'Kentucky',LA:'Louisiana',ME:'Maine',MD:'Maryland',MA:'Massachusetts',MI:'Michigan',MN:'Minnesota',MS:'Mississippi',MO:'Missouri',MT:'Montana',NE:'Nebraska',NV:'Nevada',NH:'New Hampshire',NJ:'New Jersey',NM:'New Mexico',NY:'New York',NC:'North Carolina',ND:'North Dakota',OH:'Ohio',OK:'Oklahoma',OR:'Oregon',PA:'Pennsylvania',RI:'Rhode Island',SC:'South Carolina',SD:'South Dakota',TN:'Tennessee',TX:'Texas',UT:'Utah',VT:'Vermont',VA:'Virginia',WA:'Washington',WV:'West Virginia',WI:'Wisconsin',WY:'Wyoming',DC:'District of Columbia'};
 const output={};source.forEach((p,i)=>{
  const ship=p.shipping,bill=p.billing;
  const address=a=>({firstName:a.firstName,lastName:a.lastName,addressLine1:a.address,addressLine2:a.address2,city:a.city,countryName:a.country==='US'?'United States':a.country,countryCode:a.country,state:STATES[a.state.toUpperCase()]||a.state,zipCode:a.zip});
  const id=randomUUID();output[id]={name:p.name,email:p.email,phoneNumber:p.phone,billingSameAsShipping:JSON.stringify(address(ship))===JSON.stringify(address(bill)),oneCheckout:false,quickTask:false,
   card:{holder:p.card.cardholder,number:p.card.number,expiration:p.card.expiration,cvv:p.card.cvv,type:p.card.type},shipping:address(ship),billing:address(bill),id,totalSpent:0};
 });
 return {name:'Valor_'+(retailer==='walmart'?'Walmart':'PokemonCenter')+'.json',body:JSON.stringify(output,null,2),mime:'application/json'};
}
module.exports={RETAILERS,clean,list,phoneOf,customerId,displayName,tierCount,postal,roster,savedDetails,linked,poolSearch,slotRows,exportTemplates};
