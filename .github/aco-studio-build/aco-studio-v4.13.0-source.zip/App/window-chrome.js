'use strict';
// Native actions: the renderer cannot invoke them on other windows.
function registerWindowChrome({ipcMain,BrowserWindow,mainWindow}){
 const guard=event=>{
  const win=mainWindow();
  if(!win||win.isDestroyed()||!win.webContents||win.webContents.id!==event.sender.id)
   throw Error('Window action is not available from this view.');
  return win;
 };
 ipcMain.handle('window:minimize',event=>{guard(event).minimize();return true;});
 ipcMain.handle('window:maximize',event=>{const win=guard(event);if(win.isMaximized())win.unmaximize();else win.maximize();return win.isMaximized();});
 ipcMain.handle('window:close',event=>{guard(event).close();return true;});
 ipcMain.handle('window:isMaximized',event=>guard(event).isMaximized());
 ipcMain.handle('window:platform',event=>{guard(event);return process.platform;});
}
module.exports={registerWindowChrome};
