'use strict';
/**
 * Owner-only, device-local card vault. No network access. Uses Electron safeStorage
 * (DPAPI on Windows, Keychain on macOS). Raw numbers and customer-specific custom
 * reference codes never leave the main process through list/read IPC responses.
 * A custom code is application metadata, NOT a payment CVV/CVC/CID.
 */
const fsDefault=require('node:fs/promises');
const path=require('node:path');
const {randomUUID}=require('node:crypto');
const KEY=/^[a-zA-Z0-9:_@.\-]{1,180}$/;
const text=v=>String(v??'').trim();
function customerKey(raw){const k=text(raw);if(!KEY.test(k)||k.includes('..'))throw Error('Choose a valid customer record before saving cards.');return k;}
function validateCard(data){
 const number=text(data?.number).replace(/[\s-]/g,'');
 const expMonth=text(data?.expMonth).padStart(2,'0');
 const expYear=text(data?.expYear);
 const cardholder=text(data?.cardholder);
 const code=text(data?.customCode);
 if(!/^\d{12,19}$/.test(number))throw Error('Enter a complete 12–19 digit card number.');
 if(!/^(0[1-9]|1[0-2])$/.test(expMonth))throw Error('Enter a valid expiration month.');
 if(!/^20\d\d$/.test(expYear))throw Error('Enter a four-digit expiration year.');
 if(!cardholder||cardholder.length>120)throw Error('Enter the cardholder name.');
 if(code.length>64||/[\x00-\x1f\x7f]/.test(code))throw Error('Custom security/reference code must be one line of up to 64 characters.');
 if(data?.cvv||data?.cvc||data?.cid||data?.securityCode)throw Error('Payment verification codes (CVV/CVC/CID) cannot be stored. Use the separate non-payment custom code field.');
 return {label:text(data?.label).slice(0,70)||'Local card',cardholder,number,expMonth,expYear,
  brand:text(data?.brand).slice(0,35),customCode:code};
}
function summary(card){return {id:card.id,label:card.label,cardholder:card.cardholder,last4:card.number.slice(-4),
 expMonth:card.expMonth,expYear:card.expYear,brand:card.brand,hasCustomCode:Boolean(card.customCode),createdAt:card.createdAt};}
function makeVault({baseDir,safeStorage,fs=fsDefault,now=()=>new Date().toISOString(),uuid=randomUUID,fileName='jig-studio-local-cards.encrypted'}={}){
 if(!baseDir||!safeStorage)throw Error('Local vault path and OS encryption are required.');
 if(!['jig-studio-local-cards.encrypted','jig-studio-personal-cards.encrypted'].includes(fileName))throw Error('Unsupported local vault identity.');
 const target=path.join(baseDir,fileName);
 let pending=Promise.resolve();
 function encrypted(){if(!safeStorage.isEncryptionAvailable())throw Error('Secure Windows/macOS OS encryption is unavailable. No card information was saved.');}
 async function read(){
  encrypted();
  let bytes;try{bytes=await fs.readFile(target);}catch(e){if(e.code==='ENOENT')return {version:1,customers:{}};throw e;}
  let data;try{data=JSON.parse(safeStorage.decryptString(bytes));}catch{throw Error('Unable to unlock your saved cards on this device. The encrypted vault was not overwritten.');}
  if(data?.version!==1||typeof data.customers!=='object'||!data.customers)throw Error('Unrecognized encrypted card vault; it was not modified.');
  return data;
 }
 async function write(data){
  encrypted();
  await fs.mkdir(baseDir,{recursive:true,mode:0o700});
  const tmp=target+'.'+process.pid+'.tmp';
  await fs.writeFile(tmp,safeStorage.encryptString(JSON.stringify(data)),{mode:0o600});
  try{await fs.rename(tmp,target);}catch(e){await fs.unlink(tmp).catch(()=>{});throw e;}
 }
 function schedule(fn){
  const result=pending.then(fn);
  pending=result.then(()=>undefined,()=>undefined);
  return result;
 }
 function entry(data,k){return data.customers[k]??{cards:[],assignments:[],updatedAt:null};}
 return Object.freeze({
  path:target,
  available:()=>safeStorage.isEncryptionAvailable(),
  async list(rawKey){const k=customerKey(rawKey);await pending;const d=await read(),e=entry(d,k);return {cards:e.cards.map(summary),assignments:e.assignments||[],assignmentImportKey:e.assignmentImportKey||null,updatedAt:e.updatedAt};},
  async add(rawKey,data){const k=customerKey(rawKey),fields=validateCard(data);return schedule(async()=>{
   const d=await read(),e=entry(d,k);
   if(e.cards.length>=(fileName==='jig-studio-personal-cards.encrypted'?500:100))throw Error('This encrypted card vault has reached its card limit.');
   const c={id:uuid(),...fields,createdAt:now()};e.cards.push(c);e.updatedAt=now();d.customers[k]=e;
   await write(d);return summary(c);
  });},
  async remove(rawKey,cardId){const k=customerKey(rawKey),id=text(cardId);return schedule(async()=>{
   const d=await read(),e=entry(d,k),length=e.cards.length;
   e.cards=e.cards.filter(c=>c.id!==id);
   if(e.cards.length===length)throw Error('Saved local card was not found.');
   e.assignments=(e.assignments||[]).filter(a=>a.cardId!==id);e.updatedAt=now();d.customers[k]=e;
   await write(d);return {removed:true};
  });},
  async distribute(rawKey,cardIds,count){const k=customerKey(rawKey);return schedule(async()=>{
   const d=await read(),e=entry(d,k);
   const n=Number(count);
   if(!Number.isSafeInteger(n)||n<1||n>500)throw Error('Choose 1–500 profiles.');
   if(!Array.isArray(cardIds)||!cardIds.length||cardIds.length>100)throw Error('Select one or more saved cards.');
   const choices=[...new Set(cardIds.map(text))];
   if(choices.some(id=>!e.cards.some(c=>c.id===id)))throw Error('One or more saved cards no longer exist.');
   e.assignments=Array.from({length:n},(_,i)=>({slot:i+1,cardId:choices[i%choices.length]}));
   e.updatedAt=now();d.customers[k]=e;await write(d);
   return {assignments:e.assignments.map(a=>({...a,last4:e.cards.find(c=>c.id===a.cardId).number.slice(-4)})),updatedAt:e.updatedAt};
  });},
  async assignOneToOne(rawKey,cardIds,count,importKey){const k=customerKey(rawKey);return schedule(async()=>{
   const d=await read(),e=entry(d,k),n=Number(count);
   if(!Number.isSafeInteger(n)||n<1||n>500)throw Error('Choose between 1 and 500 personal profiles.');
   if(typeof importKey!=='string'||!/^[0-9a-f-]{36}$/.test(importKey))throw Error('Select a specific imported profile file to save 1:1 card assignments.');
   if(!Array.isArray(cardIds)||cardIds.length!==n||new Set(cardIds).size!==n)
    throw Error('One-to-one card assignment requires a different saved card for every profile.');
   if(cardIds.some(id=>!e.cards.some(c=>c.id===id)))throw Error('Selected personal card not found in the encrypted vault.');
   e.assignments=cardIds.map((cardId,i)=>({slot:i+1,cardId}));e.assignmentImportKey=importKey;e.updatedAt=now();d.customers[k]=e;
   await write(d);return {assignments:e.assignments.map(a=>({...a,last4:e.cards.find(c=>c.id===a.cardId).number.slice(-4)}))};
  });},
  async cardForExport(rawKey,count,importKey){
   const k=customerKey(rawKey);await pending;const d=await read(),e=entry(d,k),n=Number(count);
   if(!Number.isInteger(n)||n<1||n>500)throw Error('Invalid profile quantity.');
   if(k==='personal:owner'&&(!importKey||e.assignmentImportKey!==importKey))throw Error('Personal card assignments belong to a different imported file. Assign cards to this file first.');
   const lookup=new Map(e.cards.map(c=>[c.id,c]));
   return Array.from({length:n},(_,i)=>{
    const assigned=(e.assignments||[]).find(x=>x.slot===i+1),card=assigned?lookup.get(assigned.cardId):null;
    return card?{cardholder:card.cardholder,number:card.number,month:card.expMonth,year:card.expYear,type:card.brand,cvv:''}:null;
   });
  }
 });
}
module.exports={customerKey,validateCard,summary,makeVault};
