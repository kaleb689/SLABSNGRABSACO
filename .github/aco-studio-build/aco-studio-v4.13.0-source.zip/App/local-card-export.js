'use strict';
// Export ONLY an owner-requested local file. Never post or sync card values online.
// Custom internal reference codes are NOT payment verification CVVs and are not
// mapped into the cc_cvv / card.cvv fields of Shikari or Valor.
const {randomUUID}=require('node:crypto');
const assertPlainObject=x=>x&&typeof x==='object'&&!Array.isArray(x);
const quote=x=>'"'+String(x??'').replace(/"/g,'""').replace(/^[=+@-]/,"'$&")+'"';
function serialize({records,fileName},cards){
 if(!Array.isArray(records)||records.length<1||records.length>500||records.some(x=>!assertPlainObject(x)))throw Error('Choose between 1 and 500 valid profiles.');
 if(!Array.isArray(cards)||cards.length!==records.length)throw Error('Saved local card assignments do not match the selected profiles.');
 const row=records[0],name=String(fileName||'local-profiles').replace(/[^a-z0-9._-]/gi,'_').slice(0,100);
 const isShikari=['cc_number','cc_exp_month','cc_exp_year','cc_cvv'].every(k=>Object.hasOwn(row,k));
 const isValor=assertPlainObject(row.card)&&['holder','number','expiration','cvv'].every(k=>Object.hasOwn(row.card,k));
 if(!isShikari&&!isValor)throw Error('Only Shikari CSV or Valor JSON profiles can use saved local cards.');
 if(records.some(r=>isShikari?['cc_number','cc_exp_month','cc_exp_year','cc_cvv'].some(k=>!Object.hasOwn(r,k)):!assertPlainObject(r.card)))
  throw Error('Mixed or damaged retailer profile format.');
 const changed=records.map((r,i)=>{
  const c=cards[i];if(!c)return r;
  // This is a saved owner-created local card, not a website payment method.
  if(isShikari)return {...r,cc_number:c.number,cc_exp_month:c.month,cc_exp_year:c.year,cc_cvv:''};
  return {...r,card:{...r.card,holder:c.cardholder,number:c.number,expiration:c.month+'/'+c.year.slice(-2),cvv:'',type:c.type||r.card.type||''}};
 });
 if(isShikari){
  const header=Object.keys(row);
  return {name:(name.replace(/\.csv$/i,'')||'Shikari')+'-local.csv',body:[header.join(','),...changed.map(r=>header.map(k=>quote(r[k])).join(','))].join('\r\n')+'\r\n',mime:'text/csv',count:changed.length,assigned:cards.filter(Boolean).length};
 }
 const obj=Object.create(null);
 changed.forEach((r,i)=>{
  const id=String(r.id||randomUUID());if(!/^[a-z0-9_-]{8,128}$/i.test(id)||['__proto__','constructor','prototype'].includes(id)||Object.hasOwn(obj,id))throw Error('Invalid or duplicate Valor profile ID.');
  obj[id]=r;
 });
 return {name:(name.replace(/\.json$/i,'')||'Valor')+'-local.json',body:JSON.stringify(obj,null,2),mime:'application/json',count:changed.length,assigned:cards.filter(Boolean).length};
}
module.exports={serialize};
