#!/bin/bash
# Upgrade a locally installed owner app from a trusted source-only ZIP.
# Requires no Node.js and never accesses the Application Support data directory.
set -euo pipefail
export PATH="/usr/bin:/bin:/usr/sbin:/sbin:${PATH:-}"
ZIP="$1"; TARGET="$2"; CURRENT="$3"; OLD_PID="$4"
APP_ID='com.slabsngrabsaco.jigstudio.owner'
EXPECTED="$HOME/Applications/SLABSNGRABSACO Jig Studio.app"
STAGE="$HOME/Applications/.JigStudio-update-stage-$$.app"
BACKUP="$HOME/Applications/.JigStudio-update-backup-$$.app"
SCRATCH=''
MOVED=0
SUCCESS=0
LOG="$HOME/Library/Logs/JigStudio-update.log"
mkdir -p "$HOME/Library/Logs"
log() { printf '[%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"; }
cleanup() {
  code=$?
  if [[ "$SUCCESS" -ne 1 && "$MOVED" -eq 1 && -d "$BACKUP" && ! -d "$TARGET" ]]; then
    /bin/mv "$BACKUP" "$TARGET" || true
  fi
  if [[ -n "$SCRATCH" && -d "$SCRATCH" ]]; then rm -rf "$SCRATCH"; fi
  if [[ -d "$STAGE" ]]; then rm -rf "$STAGE"; fi
  case "$0" in "${TMPDIR:-/tmp/}"jigstudio-mac-update-*.sh) /bin/rm -f "$0" ;; esac
  if [[ "$code" -ne 0 ]]; then log 'FAILED: update could not be applied. Existing installation should remain available.'; fi
}
trap cleanup EXIT
[[ "$(uname -s)" == 'Darwin' ]] || { log 'macOS only'; exit 1; }
[[ "$TARGET" == "$EXPECTED" ]] || { log 'Destination is not the approved private Jig Studio app'; exit 1; }
[[ -f "$ZIP" && -d "$TARGET" ]] || { log 'Update ZIP or installed application missing'; exit 1; }
[[ "$CURRENT" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { log 'Invalid current version'; exit 1; }
[[ "$OLD_PID" =~ ^[0-9]+$ ]] || { log 'Invalid current process ID'; exit 1; }
# Source ZIPs are small. Reject unrelated archives and obvious decompression bombs.
ZIP_SIZE="$(/usr/bin/stat -f%z "$ZIP")"
[[ "$ZIP_SIZE" =~ ^[0-9]+$ ]] && (( ZIP_SIZE <= 30000000 )) || { log 'ZIP too large'; exit 1; }
NAMES="$(/usr/bin/unzip -Z -1 "$ZIP")" || { log 'Unreadable ZIP'; exit 1; }
while IFS= read -r name; do
  [[ -n "$name" && "$name" != /* && "$name" != *\\* && "$name" != *:* && "$name" != *'//'* ]] || { log 'Archive path rejected'; exit 1; }
  OIFS="$IFS"; IFS='/'; read -r -a parts <<< "$name"; IFS="$OIFS"
  for part in "${parts[@]}"; do [[ "$part" != '..' ]] || { log 'Archive traversal rejected'; exit 1; }; done
done <<< "$NAMES"
UNCOMPRESSED="$(/usr/bin/unzip -l "$ZIP" | /usr/bin/tail -n 1 | /usr/bin/awk '{print $1}')"
[[ "$UNCOMPRESSED" =~ ^[0-9]+$ ]] && (( UNCOMPRESSED <= 60000000 )) || { log 'Archive contents too large'; exit 1; }
SCRATCH="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp/}jigstudio-mac-update.XXXXXX")"
mkdir -p "$SCRATCH/extracted"
/usr/bin/ditto -x -k "$ZIP" "$SCRATCH/extracted"
if [[ -n "$(/usr/bin/find "$SCRATCH/extracted" -type l -print -quit)" ]]; then log 'Update archive contained symbolic links'; exit 1; fi
CANDIDATES="$(/usr/bin/find "$SCRATCH/extracted" -type f -name package.json)"
[[ -n "$CANDIDATES" ]] || { log 'Update ZIP missing package.json'; exit 1; }
SRC=''; COUNT=0
while IFS= read -r pkg; do
  DIR="$(dirname "$pkg")"
  if ! /usr/bin/grep -Eq '"name"[[:space:]]*:[[:space:]]*"slabsngrabsaco-jig-studio"' "$pkg"; then continue; fi
  if ! /usr/bin/grep -Eq '"appId"[[:space:]]*:[[:space:]]*"com.slabsngrabsaco.jigstudio.owner"' "$pkg"; then continue; fi
  for f in main.js preload.js index.html desktop-updates.js mac-update.sh; do
    [[ -f "$DIR/$f" ]] || { log "Missing update file $f"; exit 1; }
  done
  SRC="$DIR"; (( COUNT += 1 ))
done <<< "$CANDIDATES"
[[ "$COUNT" -eq 1 ]] || { log 'Update must contain exactly one owner application'; exit 1; }
NEW="$(/usr/bin/sed -nE 's/^[[:space:]]*"version"[[:space:]]*:[[:space:]]*"([0-9]+\.[0-9]+\.[0-9]+)".*/\1/p' "$SRC/package.json" | /usr/bin/head -n 1)"
[[ "$NEW" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { log 'Update version invalid'; exit 1; }
IFS='.' read -r n1 n2 n3 <<< "$NEW"
IFS='.' read -r c1 c2 c3 <<< "$CURRENT"
(( (10#$n1 > 10#$c1) || (10#$n1 == 10#$c1 && 10#$n2 > 10#$c2) || (10#$n1 == 10#$c1 && 10#$n2 == 10#$c2 && 10#$n3 > 10#$c3) )) || { log 'Update is not newer than installed version'; exit 1; }
# Wait for originating Electron process to exit before replacing its bundle.
for i in {1..150}; do
  if ! /bin/kill -0 "$OLD_PID" 2>/dev/null; then break; fi
  /bin/sleep 0.4
done
if /bin/kill -0 "$OLD_PID" 2>/dev/null; then log 'App did not quit for update'; exit 1; fi
log "Applying owner release $CURRENT -> $NEW"
/usr/bin/ditto "$TARGET" "$STAGE"
/bin/rm -rf "$STAGE/Contents/Resources/app"
/bin/mkdir -p "$STAGE/Contents/Resources/app"
/usr/bin/ditto "$SRC" "$STAGE/Contents/Resources/app"
PLIST="$STAGE/Contents/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString $NEW" "$PLIST"
/usr/libexec/PlistBuddy -c "Set :CFBundleVersion ${NEW//./}" "$PLIST"
/usr/bin/codesign --force --deep --sign - "$STAGE"
/usr/bin/codesign --verify --deep --strict "$STAGE"
/bin/mv "$TARGET" "$BACKUP"
MOVED=1
/bin/mv "$STAGE" "$TARGET"
SUCCESS=1
log "Installed version $NEW."
/usr/bin/open "$TARGET" || log 'Could not open updated application automatically.'
if [[ -d "$BACKUP" ]]; then /bin/rm -rf "$BACKUP"; fi
