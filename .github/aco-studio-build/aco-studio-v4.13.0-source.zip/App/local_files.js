'use strict';
// Files are opened only after the current user selects them in the OS dialog.
const fs = require('node:fs/promises');
const path = require('node:path');
const {TextDecoder} = require('node:util');
const VALID = new Set(['.csv','.tsv','.tab','.psv','.json','.jsonl','.ndjson','.txt']);
const MAX_BYTES = 26 * 1024 * 1024;
const MAX_BATCH_BYTES = 100 * 1024 * 1024;
async function readSelectedFiles(paths, fileSystem=fs){
  if(!Array.isArray(paths) || paths.length>100)throw Error('Choose at most 100 files at once.');
  const entries=[];let batchBytes=0;
  for(const filePath of paths){
    if(typeof filePath!=='string' || !path.isAbsolute(filePath))throw Error('Invalid local file selection.');
    if(!VALID.has(path.extname(filePath).toLowerCase()))throw Error('Unsupported format: '+path.basename(filePath));
    const info=await fileSystem.stat(filePath);
    if(!info.isFile())throw Error('Selected path is not a file: '+path.basename(filePath));
    if(info.size>MAX_BYTES)throw Error('The file '+path.basename(filePath)+' is larger than 26 MB.');
    batchBytes+=info.size;
    if(batchBytes>MAX_BATCH_BYTES)throw Error('Select at most 100 MB total in one import.');
    const bytes=await fileSystem.readFile(filePath);
    if(bytes.byteLength>MAX_BYTES)throw Error('The file '+path.basename(filePath)+' is larger than 26 MB.');
    let text;
    try{text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch(_){throw Error('The file '+path.basename(filePath)+' is not valid UTF-8 text.');}
    entries.push({name:path.basename(filePath),text});
  }
  return entries;
}
module.exports={readSelectedFiles,MAX_BYTES};
