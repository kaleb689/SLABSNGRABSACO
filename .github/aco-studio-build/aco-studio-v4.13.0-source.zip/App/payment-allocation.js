/* Private, session-only test-card allocation. No browser storage, website writes or vault reads.
 * Only explicitly entered synthetic test values are eligible for file export.
 */
(function(root,factory){
 const api=factory();
 if(typeof module==='object'&&module.exports)module.exports=api;
 if(root)root.JigPaymentAllocation=api;
})(typeof window!=='undefined'?window:null,function(){
 'use strict';
 const val=x=>String(x??'').trim();
 function normalize(raw){
  if(raw?.synthetic!==true)throw Error('Confirm that these are synthetic test-card values, not live customer cards.');
  const number=val(raw.number).replace(/[\s-]/g,'');
  const month=val(raw.month).padStart(2,'0');
  const year=val(raw.year);
  const cvv=val(raw.cvv);
  const cardholder=val(raw.cardholder);
  if(!cardholder||cardholder.length>120)throw Error('Enter the test cardholder name (up to 120 characters).');
  if(!/^\d{12,19}$/.test(number))throw Error('Enter a 12–19 digit synthetic test card number.');
  if(!/^(0[1-9]|1[0-2])$/.test(month))throw Error('Enter a valid expiration month (01–12).');
  if(!/^20\d{2}$/.test(year))throw Error('Enter a four-digit expiration year (20XX).');
  if(cvv&&!/^\d{3,4}$/.test(cvv))throw Error('Synthetic test security code must be three or four digits.');
  return Object.freeze({synthetic:true,label:val(raw.label).slice(0,70)||'Test card',cardholder,number,month,year,cvv,type:val(raw.type).slice(0,30)});
 }
 function even(cards,count,indices){
  if(!Array.isArray(cards)||cards.length<1||cards.length>100)throw Error('Add at least one card before distributing.');
  if(!Number.isSafeInteger(count)||count<1||count>500)throw Error('Load between 1 and 500 profiles before distributing cards.');
  const targets=indices==null?Array.from({length:count},(_,i)=>i):[...new Set(indices)].filter(i=>Number.isInteger(i)&&i>=0&&i<count).sort((a,b)=>a-b);
  const result=Array(count).fill(null);
  targets.forEach((row,i)=>{result[row]=cards[i%cards.length]});
  return result;
 }
 function detect(records){
  if(!Array.isArray(records)||!records.length)return null;
  const row=records[0];
  if(row&&typeof row==='object'&&Object.hasOwn(row,'cc_number')&&Object.hasOwn(row,'cc_exp_month')&&Object.hasOwn(row,'cc_exp_year')&&Object.hasOwn(row,'cc_cvv'))return 'shikari';
  if(row?.card&&typeof row.card==='object'&&['holder','number','expiration','cvv','type'].every(k=>Object.hasOwn(row.card,k)))return 'valor';
  return null;
 }
 function fillRows(records,cards,indices){
  const format=detect(records);
  if(!format)throw Error('Card assignment supports Shikari CSV and Valor JSON only. Import or generate a matching retailer file first.');
  const assigned=even(cards,records.length,indices);
  const rows=records.map((r,i)=>{
   if(!assigned[i])return r;
   const card=assigned[i];
   if(card.synthetic!==true)throw Error('Only manually entered synthetic test cards can be exported.');
   if(format==='shikari')return {...r,cc_number:card.number,cc_exp_month:card.month,cc_exp_year:card.year,cc_cvv:card.cvv};
   return {...r,card:{...r.card,holder:card.cardholder,number:card.number,expiration:card.month+'/'+card.year.slice(-2),cvv:card.cvv,type:card.type||r.card.type||''}};
  });
  return {records:rows,format,assignedCount:assigned.filter(Boolean).length};
 }
 function summary(cards,count,indices){
  return even(cards,count,indices).map((card,index)=>card?{
   index,slot:index+1,label:card.label,last4:card.number.slice(-4),holder:card.cardholder
  }:null);
 }
 return Object.freeze({normalize,even,detect,fillRows,summary});
});
