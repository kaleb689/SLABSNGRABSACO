/* Locally saved customer cards. Main-process OS-encrypted vault, no website writes. */
(()=>{'use strict';
 const api=window.desktopAPI?.localCards;
 const d=document,$=id=>d.getElementById(id);
 if(!api)return;
 let customer='',customerName='',maxProfiles=0,items=[],selected=new Set(),assignments=[],returnFocus=null;
 const dialog=d.createElement('div');dialog.id='ownerCardsDialog';dialog.className='ownerCardsDialog';dialog.hidden=true;
 dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-label','Local customer cards');
 dialog.innerHTML=`<div class="ownerCardsWindow"><header class="ownerCardsHeader"><div><span class="eyebrow">PRIVATE LOCAL VAULT • NOT ON THE WEBSITE</span><h2>Saved customer cards</h2><small id="localCardsCustomer"></small></div><button type="button" class="ownerCardsClose" id="localCardsClose" aria-label="Close local card manager">✕</button></header>
 <div class="ownerCardsBody"><section class="ownerCardsPanel"><h3>Add a card to this customer</h3><p>Saved on this Windows or Mac only, encrypted with your operating system's credential protection.</p>
 <form id="localCardsForm" autocomplete="off"><label>Card label<input name="label" maxlength="70" placeholder="e.g. Business card" autocomplete="off" required></label><label>Cardholder name<input name="cardholder" maxlength="120" placeholder="Name on card" autocomplete="off" required></label>
 <label class="ownerCardsSpan">Card number<input name="number" type="text" inputmode="numeric" maxlength="26" placeholder="Full card number" autocomplete="off" required></label>
 <div class="ownerCardsDual"><label>Expiry month<input name="expMonth" type="text" inputmode="numeric" maxlength="2" placeholder="MM" autocomplete="off" required></label><label>Expiry year<input name="expYear" type="text" inputmode="numeric" maxlength="4" placeholder="YYYY" autocomplete="off" required></label></div>
 <label>Card brand<select name="brand"><option>Visa</option><option>Mastercard</option><option>American Express</option><option>Discover</option><option>Other</option></select></label>
 <label>Custom security / reference code <span class="ownerCardsOptional">(not CVV/CVC/CID)</span><input name="customCode" type="password" maxlength="64" placeholder="Optional non-payment project code" autocomplete="off"></label>
 <p class="ownerCardsWarn">This custom field is not a payment verification code. CVV/CVC/CID must never be entered or saved here.</p>
 <button class="ownerCardsSave" type="submit">+ Save card to this device</button></form></section>
 <section class="ownerCardsPanel"><h3>Saved cards <span id="localCardsCount"></span></h3><p>Select the cards to assign to this customer's profiles, then distribute them evenly. Your choices remain on this device.</p><div id="localCardsList" class="ownerCardsList"></div><div class="ownerCardsDistribution"><label>Profile count<input id="localCardsProfileCount" type="number" inputmode="numeric" min="1" max="500" value="1"></label><button class="ownerCardsDistribute" type="button" id="localCardsDistribute">Distribute evenly</button></div><div id="localCardsAssignments" class="ownerCardsAssignments"></div></section></div>
 <footer class="ownerCardsFooter"><span id="localCardsStatus" role="status">No website records are modified.</span><button type="button" class="ownerCardsDone" id="localCardsDone">Done</button></footer></div>`;
 d.body.append(dialog);
 const form=$('localCardsForm');
 const status=(text,error=false)=>{const e=$('localCardsStatus');e.textContent=text;e.classList.toggle('error',error);};
 const selectSafe=(value)=>String(value??'');
 function optionId(card){return 'local-card-'+card.id.replace(/[^a-z0-9_-]/gi,'');}
 function render(){
  const list=$('localCardsList');list.replaceChildren();$('localCardsCount').textContent='('+items.length+')';
  if(!items.length){const msg=d.createElement('p');msg.className='ownerCardsEmpty';msg.textContent='No locally saved cards for this customer. Add one on the left.';list.append(msg);}
  for(const card of items){
   const row=d.createElement('div');row.className='ownerCardItem';
   const label=d.createElement('label');label.setAttribute('for',optionId(card));
   const cb=d.createElement('input');cb.type='checkbox';cb.id=optionId(card);cb.checked=selected.has(card.id);
   cb.addEventListener('change',()=>{if(cb.checked)selected.add(card.id);else selected.delete(card.id);});
   const name=d.createElement('span');name.className='ownerCardItemText';
   const title=d.createElement('strong');title.textContent=card.label;
   const detail=d.createElement('small');detail.textContent=[card.brand,card.cardholder,'•••• '+card.last4,'Exp '+card.expMonth+'/'+card.expYear,card.hasCustomCode?'Custom code saved':null].filter(Boolean).join(' · ');
   name.append(title,detail);label.append(cb,name);
   const remove=d.createElement('button');remove.type='button';remove.textContent='Remove';remove.className='ownerCardsRemove';
   remove.setAttribute('aria-label','Remove '+card.label);
   remove.addEventListener('click',async()=>{if(!confirm('Remove '+card.label+' from this computer? Website payment methods will not change.'))return;
    try{remove.disabled=true;await api.remove(customer,card.id);await refresh();status('Removed the local card. The website and customer app were not changed.');}catch(e){status(e.message||'Could not remove card.',true);}finally{remove.disabled=false;}});
   row.append(label,remove);list.append(row);
  }
  const area=$('localCardsAssignments');area.replaceChildren();
  for(const a of assignments.slice(0,100)){
   const card=items.find(x=>x.id===a.cardId);if(!card)continue;
   const p=d.createElement('div');p.className='ownerCardAssignment';p.textContent='Profile '+a.slot+' · '+card.label+' •••• '+card.last4;area.append(p);
  }
 }
 async function refresh(){
  if(!customer)return;
  const result=await api.list(customer);items=result.cards||[];assignments=result.assignments||[];
  selected=new Set(items.map(x=>x.id));render();
 }
 function close(){dialog.hidden=true;form.reset();customer='';items=[];assignments=[];selected.clear();returnFocus?.focus?.();}
 $('localCardsClose').addEventListener('click',close);$('localCardsDone').addEventListener('click',close);
 dialog.addEventListener('click',e=>{if(e.target===dialog)close();});
 d.addEventListener('keydown',e=>{if(!dialog.hidden&&e.key==='Escape'){e.preventDefault();close();}});
 form.addEventListener('submit',async e=>{
  e.preventDefault();const button=form.querySelector('button[type=submit]');button.disabled=true;
  try{
   const f=new FormData(form);
   await api.add(customer,Object.fromEntries(f.entries()));form.reset();await refresh();
   status('Card saved locally and encrypted. Nothing was sent to your website or customer app.');
  }catch(error){status(error.message||'Could not save card to this device.',true);}
  finally{button.disabled=false;}
 });
 $('localCardsDistribute').addEventListener('click',async()=>{
  const b=$('localCardsDistribute');b.disabled=true;
  try{
   const count=Number($('localCardsProfileCount').value);
   if(count>maxProfiles)throw Error('This customer has '+maxProfiles+' confirmed profile slot(s).');
   const ids=items.filter(x=>selected.has(x.id)).map(x=>x.id);
   const result=await api.distribute(customer,ids,count);
   assignments=result.assignments;render();status('Saved '+assignments.length+' local profile-card assignments. Website records are unchanged.');
   d.dispatchEvent(new CustomEvent('jigstudio:local-card-assignments',{detail:{customerId:customer,count:assignments.length}}));
  }catch(err){status(err.message||'Could not distribute saved cards.',true);}
  finally{b.disabled=false;}
 });
 async function open(customerId,name,profileCount=1){
  returnFocus=d.activeElement;customer=String(customerId||'');customerName=String(name||'Customer');maxProfiles=Math.max(1,Math.min(500,Number(profileCount)||1));
  $('localCardsCustomer').textContent=customerName+' · Saved only on this device';
  $('localCardsProfileCount').max=String(maxProfiles);$('localCardsProfileCount').value=String(maxProfiles);
  dialog.hidden=false;form.reset();status('Loading encrypted local cards…');
  try{await refresh();status('Ready. Local cards and assignments are never uploaded to your website.');}catch(err){items=[];assignments=[];render();status(err.message||'Unable to unlock local cards.',true);}
  $('localCardsClose').focus();
 }
 window.JigStudioLocalCards=Object.freeze({open,refresh});
 const manage=$('studioManageLocalCards');if(manage){manage.addEventListener('click',()=>{
  const id=$('studioCustomerPick')?.value;
  const customers=window.JigWebsiteCustomers?.list?.()||[];
  const c=customers.find(x=>x.id===id);
  if(!c){alert('Choose a website customer in Profile Studio first.');return;}
  void open(c.id,c.name,c.tierCount);
 });}
})();
