'use strict';
const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs/promises');
const os=require('node:os');
const path=require('node:path');
const {makeJigBanks}=require('../jig-address-banks');
const vm=require('node:vm');
const appCoreSource=require('node:fs').readFileSync(path.join(__dirname,'../app.js'),'utf8').split('/* SLABSNGRABSACO Jig Studio - UI and local downloads */')[0];
const JigCore=vm.runInNewContext(appCoreSource+'; JigCore;', {require:relative=>require(path.resolve(__dirname,'..',relative))});
const JigBankAssignments=require('../jig-bank-assignment');
const {makeVault}=require('../local-card-vault');
const {serialize}=require('../local-card-export');
const specimen=(label,street,zip)=>({label,address1:street,address2:'Unit 4',city:'Testville',state:'FL',zip});
// This deterministic encoder is test-only. Production uses Electron safeStorage.
const safeStorage={isEncryptionAvailable:()=>true,encryptString:s=>Buffer.from('test-sealed:'+Buffer.from(s).toString('base64')),
 decryptString:b=>Buffer.from(b.toString('utf8').slice('test-sealed:'.length),'base64').toString('utf8')};
async function withVault(fn){const dir=await fs.mkdtemp(path.join(os.tmpdir(),'aco-jig-banks-'));
 try{return await fn(dir);}finally{await fs.rm(dir,{force:true,recursive:true});}}

test('Personal bank has a separate encrypted file from per-customer ACO banks; no cross-bank reads',()=>withVault(async dir=>{
 const store=makeJigBanks({baseDir:dir,safeStorage});
 const personal=[specimen('Main one','101 Personal Drive','33001'),specimen('Main two','202 Personal Avenue','33002')];
 const acoOne=[specimen('Member one','303 Customer Lane','33003')];
 const acoTwo=[specimen('Member two','404 Other Street','33004')];
 assert.equal((await store.importPersonal(personal)).count,2);
 assert.equal((await store.syncAco('member1',acoOne)).count,1);
 assert.equal((await store.syncAco('member2',acoTwo)).count,1);
 const mine=await store.listPersonal(),one=await store.listAco('member1'),two=await store.listAco('member2');
 assert.deepEqual(mine.addresses.map(x=>x.address1),personal.map(x=>x.address1));
 assert.deepEqual(one.addresses.map(x=>x.address1),['303 Customer Lane']);
 assert.deepEqual(two.addresses.map(x=>x.address1),['404 Other Street']);
 assert.ok(!JSON.stringify(one).includes('Personal Drive'));
 assert.ok(!JSON.stringify(mine).includes('Customer Lane'));
 const files=await fs.readdir(dir);assert.deepEqual(files.sort(),['aco-jigs-by-customer.bank.encrypted','personal-jigs.bank.encrypted']);
 for(const name of files){const contents=(await fs.readFile(path.join(dir,name))).toString();
  assert.ok(!contents.includes('Personal Drive')&&!contents.includes('Customer Lane'),'No plaintext personal/customer addresses stored');}
 await assert.rejects(store.listAco('personal:owner'),/valid membership customer ID/);
}));

test('Customer A sync never changes B; website rows retain IDs on refresh and removes stale website rows',()=>withVault(async dir=>{
 const store=makeJigBanks({baseDir:dir,safeStorage});
 const a=specimen('A','100 Legal Road','33001');
 await store.syncAco('custA',[a]);
 const before=(await store.listAco('custA')).addresses[0].id;
 await store.addAco('custA',specimen('Manual','105 Private Trail','33005'));
 await store.syncAco('custB',[specimen('B','200 Legal Road','33002')]);
 await store.syncAco('custA',[{...a,label:'New description'}]);
 const last=await store.listAco('custA');
 assert.equal(last.addresses.find(x=>x.source==='website').id,before);
 assert.equal(last.addresses.find(x=>x.source==='website').label,'New description');
 await assert.rejects(store.removeAco('custA',before),/website-saved address/);
 await assert.rejects(store.removeAco('custB',before),/does not belong/);
 await store.syncAco('custA',[]);
 assert.equal((await store.listAco('custA')).addresses.length,1,'manual ACO bank address remains');
 assert.equal((await store.listAco('custB')).addresses[0].address1,'200 Legal Road');
}));

test('bank-address assignment rejects Personal → ACO, ACO → Personal, and cross-customer use',()=>{
 const records=[{shipping_street:'1 Original Rd',shipping_city:'Testville',shipping_state:'FL',shipping_zip:'33000',billing_street:'1 Original Rd',billing_city:'Testville',billing_state:'FL',billing_zip:'33000',email:'account@example.com',cc_number:'5111222233334444'}];
 const mapping=JigCore.autoMap(records),indices=[0],addresses=[specimen('Personal','123 My Lane','33001')];
 assert.throws(()=>JigBankAssignments.assign({records,mapping,indices,addresses,scope:'personal',origin:'aco',customerId:'cust1',sourceCustomerId:'cust1'},JigCore),/cannot be used across banks/);
 assert.throws(()=>JigBankAssignments.assign({records,mapping,indices,addresses,scope:'aco',origin:'personal'},JigCore),/cannot be used across banks/);
 assert.throws(()=>JigBankAssignments.assign({records,mapping,indices,addresses,scope:'aco',origin:'aco',customerId:'cust2',sourceCustomerId:'cust1'},JigCore),/exact membership customer/);
 const out=JigBankAssignments.assign({records,mapping,indices,addresses,scope:'personal',origin:'personal'},JigCore);
 assert.equal(out.records[0].shipping_street,'123 My Lane');
 assert.equal(out.records[0].shipping_zip,'33001');
 assert.equal(out.records[0].email,records[0].email);
 assert.equal(out.records[0].cc_number,records[0].cc_number);
 assert.equal(records[0].shipping_street,'1 Original Rd','original imported record unchanged');
});

test('selected personal addresses round-robin across selected profiles, leaving others untouched',()=>{
 const records=Array.from({length:5},(_,i)=>({shipping_street:'100 Original Ave',shipping_street_2:'',shipping_city:'Oldcity',shipping_state:'FL',shipping_zip:'33001',login:'test'+i}));
 const mapping=JigCore.autoMap(records);
 const addresses=[specimen('P1','11 Elm Street','33011'),specimen('P2','22 Oak Street','33022')];
 const r=JigBankAssignments.assign({records,mapping,indices:[1,3,4],addresses,scope:'personal',origin:'personal'},JigCore);
 assert.equal(r.records[0].shipping_street,'100 Original Ave');
 assert.equal(r.records[1].shipping_street,'11 Elm Street');
 assert.equal(r.records[3].shipping_street,'22 Oak Street');
 assert.equal(r.records[4].shipping_street,'11 Elm Street');
 for(let i=0;i<records.length;i++)assert.equal(r.records[i].login,records[i].login);
});

test('personal card vault saves custom reference encrypted, 1:1 unique allocation, no stored or exported CVV',()=>withVault(async dir=>{
 let uuid=0;const vault=makeVault({baseDir:dir,safeStorage,uuid:()=>`card-${++uuid}`});
 const card={label:'My private card',cardholder:'Sample Owner',number:'4111111111111111',expMonth:'12',expYear:'2032',customCode:'NONPAYMENT-REFERENCE-A'};
 await vault.add('personal:owner',card);
 await vault.add('personal:owner',{...card,number:'5555555555554444',label:'Personal two'});
 await vault.add('memberA',{...card,number:'6000000000000001',label:'Customer A card'});
 const personal=await vault.list('personal:owner'),aco=await vault.list('memberA');
 assert.equal(personal.cards.length,2);assert.equal(aco.cards.length,1);
 assert.ok(personal.cards[0].hasCustomCode);assert.ok(!('customCode' in personal.cards[0]),'secret is not returned from listing');
 await assert.rejects(vault.add('personal:owner',{...card,cvv:'123'}),/cannot be stored/);
 await assert.rejects(vault.add('personal:owner',{...card,securityCode:'222'}),/cannot be stored/);
 const testImport='7f0fd283-7a60-4f19-ac98-4a85e966063a';
 await assert.rejects(vault.assignOneToOne('personal:owner',[personal.cards[0].id,personal.cards[0].id],2,testImport),/different saved card/);
 await assert.rejects(vault.assignOneToOne('personal:owner',[aco.cards[0].id],1,testImport),/not found/);
 
 const a=await vault.assignOneToOne('personal:owner',personal.cards.map(x=>x.id),2,testImport);
 assert.equal(a.assignments.length,2);assert.notEqual(a.assignments[0].cardId,a.assignments[1].cardId);
 assert.equal((await vault.list('memberA')).assignments.length,0);
 assert.equal((await vault.list('personal:owner')).assignmentImportKey,testImport);
 const raw=(await fs.readFile(vault.path)).toString('utf8');assert.ok(!raw.includes(card.number)&&!raw.includes(card.customCode));
 const rows=[{cc_number:'',cc_exp_month:'',cc_exp_year:'',cc_cvv:'old'}, {cc_number:'',cc_exp_month:'',cc_exp_year:'',cc_cvv:'old'}];
 await assert.rejects(vault.cardForExport('personal:owner',2,'86b0a7f3-ab34-4bd0-b04e-e35210e04da2'),/different imported file/);
 const cards=await vault.cardForExport('personal:owner',2,testImport);
 const data=serialize({fileName:'personal.csv',records:rows},cards);
 assert.ok(data.body.includes('4111111111111111'));
 assert.ok(!data.body.includes(card.customCode));assert.ok(!data.body.includes('NONPAYMENT-REFERENCE'));
 assert.ok(!data.body.includes(',old'));
}));

test('UI and Electron IPC expose separate banks and identity-bound website reads',()=>{
 const fsSync=require('node:fs');const js=n=>fsSync.readFileSync(path.join(__dirname,'..',n),'utf8');
 const main=js('main.js'),preload=js('preload.js'),html=js('index.html');
 for(const route of ['jig:personal:list','jig:personal:import','jig:aco:list','jig:aco:sync','personal:cards:assign','personal:cards:export'])assert.ok(main.includes(`ipcMain.handle('${route}'`));
 assert.match(main,/ownerSender\(event\)/);assert.match(main,/authorizeAcoBank\(id\)/);assert.match(main,/roster\?\.customers/);
 assert.match(main,/ACO snapshots MUST originate from the authenticated website bridge/);
 assert.match(main,/siteBridge\.read\('customer',\{orderId:member\.orderId\}\)/);
 assert.match(main,/startsWith\('personal:'\)/);assert.match(main,/jig-studio-personal-cards.encrypted/);
 assert.match(preload,/personalCards:Object\.freeze/);assert.match(preload,/jigBanks:Object\.freeze/);
 assert.match(html,/id="personalJigScope"/);assert.match(html,/id="acoJigScope"/);assert.match(html,/Personal Card Pool/);
 assert.match(js('profile-site-import.js'),/importWebsiteTemplate\(fileName,template.body,detail.customer.id\)/);
 assert.match(js('app.js'),/Cross-bank address assignment blocked/);
 assert.match(js('app.js'),/bindLocalImportToMember\(customerId\)/);
 assert.match(js('jig-banks-ui.js'),/assignmentImportKey===ctx\.importKey/);
});
