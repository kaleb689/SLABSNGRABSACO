'use strict';
/** Pure address overlay for supported local Shikari/Valor/delimited imports.
 * Unselected rows and every non-address field remain byte-equivalent to source.
 * Only explicit same-scope address bank selections may be applied.
 */
const JigBankAssignments=(()=>{
 const clone=x=>JSON.parse(JSON.stringify(x));
 const FIELDS=['address1','address2','city','state','zip'];
 function assign({records,mapping,indices,addresses,scope,origin,customerId,sourceCustomerId,mirrorBilling=false},engine){
  if(!Array.isArray(records)||!records.length||records.length>500)throw Error('Import profiles first.');
  if(scope!=='personal'&&scope!=='aco')throw Error('Choose Personal Jigs or ACO Jigs.');
  if(scope!==origin)throw Error('Personal and ACO addresses cannot be used across banks.');
  if(scope==='aco'&&(!customerId||!sourceCustomerId||customerId!==sourceCustomerId))throw Error('ACO addresses must match this exact membership customer.');
  if(scope==='personal'&&(customerId||sourceCustomerId))throw Error('Personal addresses cannot be assigned to membership-customer profiles.');
  if(!Array.isArray(addresses)||!addresses.length||addresses.length>500)throw Error('Select one or more addresses from this bank.');
  if(!Array.isArray(indices)||!indices.length||indices.length>records.length||new Set(indices).size!==indices.length||indices.some(n=>!Number.isInteger(n)||n<0||n>=records.length))throw Error('Select the imported profile rows to update.');
  for(const field of ['get','put','has'])if(typeof engine?.[field]!=='function')throw Error('The profile address parser is unavailable.');
  if(!mapping?.['shipping.address1']||!mapping?.['shipping.city']||!mapping?.['shipping.state']||!mapping?.['shipping.zip'])throw Error('Map the shipping address, city, state and ZIP columns first.');
  const output=clone(records),changed=[],notes=[];
  const assignRole=(row,address,role)=>{
   let changedFields=0;
   for(const field of FIELDS){
    const mapped=mapping[role+'.'+field];
    if(!mapped){if(role==='shipping'&&field!=='address2')throw Error('Missing '+role+' '+field+' mapping.');continue;}
    const value=String(address[field]??'');
    if(!engine.has(row,mapped))throw Error('Mapped '+role+' '+field+' field does not exist.');
    if(!engine.put(row,mapped,value)){
     if(String(engine.get(row,mapped)??'')!==value)throw Error('Cannot modify the protected '+role+' '+field+' field.');
    }else changedFields++;
   }
   return changedFields;
  };
  for(let n=0;n<indices.length;n++){
   const index=indices[n],address=addresses[n%addresses.length],next=output[index];
   const shipChanged=assignRole(next,address,'shipping');
   const billChanged=mirrorBilling?assignRole(next,address,'billing'):0;
   changed.push({index,addressId:address.id||null,shipping:shipChanged,billing:billChanged});
   notes.push({index,text:'Selected '+scope+' bank address '+(n%addresses.length+1)+' of '+addresses.length});
  }
  return {records:output,changed,notes};
 }
 return Object.freeze({assign});
})();
if(typeof module!=='undefined'&&module.exports)module.exports=JigBankAssignments;
if(typeof window!=='undefined')window.JigBankAssignments=JigBankAssignments;
